-- Seed expenses
INSERT INTO expenses (description, category, amount, date)
VALUES
  ('فواتير الكهرباء', 'مرافق', 2500, '2023-05-12'),
  ('رواتب الموظفين', 'رواتب', 15000, '2023-05-10'),
  ('شراء مواد خام', 'مواد خام', 7800, '2023-05-08'),
  ('صيانة المعدات', 'صيانة', 1200, '2023-05-05'),
  ('فواتير المياه', 'مرافق', 800, '2023-05-03');

-- Seed inventory
INSERT INTO inventory (code, name, category, quantity, price, status)
VALUES
  ('P001', 'منتج أ', 'فئة 1', 150, 250, 'متوفر'),
  ('P002', 'منتج ب', 'فئة 2', 75, 320, 'متوفر'),
  ('P003', 'منتج ج', 'فئة 1', 5, 180, 'منخفض'),
  ('P004', 'منتج د', 'فئة 3', 0, 420, 'غير متوفر'),
  ('P005', 'منتج هـ', 'فئة 2', 200, 150, 'متوفر');

-- Seed customers
INSERT INTO customers (name, email, phone, orders, total)
VALUES
  ('أحمد محمد', 'ahmed@example.com', '01012345678', 12, 15600),
  ('سارة أحمد', 'sara@example.com', '01123456789', 8, 9200),
  ('محمد علي', 'mohamed@example.com', '01234567890', 15, 18500),
  ('فاطمة حسن', 'fatma@example.com', '01198765432', 5, 4800),
  ('خالد عبدالله', 'khaled@example.com', '01087654321', 20, 25000);

-- Seed orders
INSERT INTO orders (customer_id, order_date, status, total)
VALUES
  (1, '2023-05-15', 'مكتمل', 1500),
  (2, '2023-05-14', 'مكتمل', 2200),
  (3, '2023-05-13', 'قيد التنفيذ', 3500),
  (4, '2023-05-12', 'مكتمل', 1800),
  (5, '2023-05-11', 'ملغي', 2500);

-- Seed order_items
INSERT INTO order_items (order_id, product_id, quantity, price)
VALUES
  (1, 1, 2, 500),
  (1, 3, 3, 540),
  (2, 2, 4, 1280),
  (2, 5, 5, 750),
  (3, 1, 6, 1500),
  (3, 4, 2, 840),
  (4, 3, 10, 1800),
  (5, 5, 10, 1500),
  (5, 2, 3, 960);

