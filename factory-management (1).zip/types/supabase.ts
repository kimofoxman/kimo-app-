export type Json = string | number | boolean | null | { [key: string]: Json | undefined } | Json[]

export interface Database {
  public: {
    Tables: {
      expenses: {
        Row: {
          id: number
          description: string
          category: string
          amount: number
          date: string
          created_at: string
        }
        Insert: {
          id?: number
          description: string
          category: string
          amount: number
          date: string
          created_at?: string
        }
        Update: {
          id?: number
          description?: string
          category?: string
          amount?: number
          date?: string
          created_at?: string
        }
      }
      inventory: {
        Row: {
          id: number
          code: string
          name: string
          category: string
          quantity: number
          price: number
          status: string
          created_at: string
        }
        Insert: {
          id?: number
          code: string
          name: string
          category: string
          quantity: number
          price: number
          status: string
          created_at?: string
        }
        Update: {
          id?: number
          code?: string
          name?: string
          category?: string
          quantity?: number
          price?: number
          status?: string
          created_at?: string
        }
      }
      customers: {
        Row: {
          id: number
          name: string
          email: string
          phone: string
          orders: number
          total: number
          created_at: string
        }
        Insert: {
          id?: number
          name: string
          email: string
          phone: string
          orders?: number
          total?: number
          created_at?: string
        }
        Update: {
          id?: number
          name?: string
          email?: string
          phone?: string
          orders?: number
          total?: number
          created_at?: string
        }
      }
      orders: {
        Row: {
          id: number
          customer_id: number
          order_date: string
          status: string
          total: number
          created_at: string
        }
        Insert: {
          id?: number
          customer_id: number
          order_date: string
          status: string
          total: number
          created_at?: string
        }
        Update: {
          id?: number
          customer_id?: number
          order_date?: string
          status?: string
          total?: number
          created_at?: string
        }
      }
      order_items: {
        Row: {
          id: number
          order_id: number
          product_id: number
          quantity: number
          price: number
          created_at: string
        }
        Insert: {
          id?: number
          order_id: number
          product_id: number
          quantity: number
          price: number
          created_at?: string
        }
        Update: {
          id?: number
          order_id?: number
          product_id?: number
          quantity?: number
          price?: number
          created_at?: string
        }
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      [_ in never]: never
    }
    Enums: {
      [_ in never]: never
    }
  }
}

