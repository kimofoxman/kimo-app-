"use client"

import type React from "react"

import { useState } from "react"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Label } from "@/components/ui/label"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { addEmployee } from "@/lib/api"
import { Plus } from "lucide-react"
import { useToast } from "@/hooks/use-toast"

export function AddEmployeeDialog({ onEmployeeAdded }: { onEmployeeAdded: () => void }) {
  const { toast } = useToast()
  const [open, setOpen] = useState(false)
  const [loading, setLoading] = useState(false)
  const [formData, setFormData] = useState({
    name: "",
    position: "",
    department: "",
    salary: "",
    hire_date: new Date().toISOString().split("T")[0],
    phone: "",
    email: "",
    address: "",
  })

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target
    setFormData((prev) => ({ ...prev, [name]: value }))
  }

  const handleSelectChange = (name: string, value: string) => {
    setFormData((prev) => ({ ...prev, [name]: value }))
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)

    try {
      await addEmployee({
        name: formData.name,
        position: formData.position,
        department: formData.department,
        salary: Number.parseFloat(formData.salary),
        hire_date: formData.hire_date,
        phone: formData.phone,
        email: formData.email,
        address: formData.address,
      })

      toast({
        title: "تمت الإضافة بنجاح",
        description: "تم إضافة الموظف بنجاح",
      })

      setFormData({
        name: "",
        position: "",
        department: "",
        salary: "",
        hire_date: new Date().toISOString().split("T")[0],
        phone: "",
        email: "",
        address: "",
      })

      setOpen(false)
      onEmployeeAdded()
    } catch (error) {
      toast({
        title: "حدث خطأ",
        description: "تعذر إضافة الموظف، يرجى المحاولة مرة أخرى",
        variant: "destructive",
      })
    } finally {
      setLoading(false)
    }
  }

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button className="flex items-center gap-1">
          <Plus className="h-4 w-4" />
          <span>إضافة موظف</span>
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-[425px]">
        <DialogHeader>
          <DialogTitle>إضافة موظف جديد</DialogTitle>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4 pt-4">
          <div className="grid gap-2">
            <Label htmlFor="name">الاسم</Label>
            <Input id="name" name="name" value={formData.name} onChange={handleChange} required />
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div className="grid gap-2">
              <Label htmlFor="position">المنصب</Label>
              <Input id="position" name="position" value={formData.position} onChange={handleChange} required />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="department">القسم</Label>
              <Select
                value={formData.department}
                onValueChange={(value) => handleSelectChange("department", value)}
                required
              >
                <SelectTrigger>
                  <SelectValue placeholder="اختر القسم" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="إدارة">إدارة</SelectItem>
                  <SelectItem value="مالية">مالية</SelectItem>
                  <SelectItem value="مبيعات">مبيعات</SelectItem>
                  <SelectItem value="خدمة العملاء">خدمة العملاء</SelectItem>
                  <SelectItem value="صيانة">صيانة</SelectItem>
                  <SelectItem value="أخرى">أخرى</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div className="grid gap-2">
              <Label htmlFor="salary">الراتب</Label>
              <Input id="salary" name="salary" type="number" value={formData.salary} onChange={handleChange} required />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="hire_date">تاريخ التعيين</Label>
              <Input
                id="hire_date"
                name="hire_date"
                type="date"
                value={formData.hire_date}
                onChange={handleChange}
                required
              />
            </div>
          </div>
          <div className="grid gap-2">
            <Label htmlFor="phone">رقم الهاتف</Label>
            <Input id="phone" name="phone" value={formData.phone} onChange={handleChange} required />
          </div>
          <div className="grid gap-2">
            <Label htmlFor="email">البريد الإلكتروني</Label>
            <Input id="email" name="email" type="email" value={formData.email} onChange={handleChange} required />
          </div>
          <div className="grid gap-2">
            <Label htmlFor="address">العنوان</Label>
            <Input id="address" name="address" value={formData.address} onChange={handleChange} required />
          </div>
          <div className="flex justify-end gap-2">
            <Button type="button" variant="outline" onClick={() => setOpen(false)}>
              إلغاء
            </Button>
            <Button type="submit" disabled={loading}>
              {loading ? "جاري الإضافة..." : "إضافة"}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  )
}

