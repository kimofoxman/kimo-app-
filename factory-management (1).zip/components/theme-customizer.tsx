"use client"

import { useEffect, useState } from "react"
import { useTheme } from "next-themes"
import { useToast } from "@/hooks/use-toast"

// أنواع السمات المتاحة
export type ColorTheme = "blue" | "purple" | "green" | "amber"
export type FontSize = "small" | "medium" | "large"

// الألوان الخاصة بكل سمة
const themeColors = {
  blue: {
    primary: "221 83% 53%",
    ring: "221 83% 53%",
  },
  purple: {
    primary: "270 76% 53%",
    ring: "270 76% 53%",
  },
  green: {
    primary: "142 76% 36%",
    ring: "142 76% 36%",
  },
  amber: {
    primary: "38 92% 50%",
    ring: "38 92% 50%",
  },
}

// حجم الخط لكل خيار
const fontSizes = {
  small: {
    base: "0.875rem",
    heading: "1.25rem",
  },
  medium: {
    base: "1rem",
    heading: "1.5rem",
  },
  large: {
    base: "1.125rem",
    heading: "1.75rem",
  },
}

// استخدام localStorage لتخزين التفضيلات
const storeThemePreference = (key: string, value: string) => {
  if (typeof window !== "undefined") {
    localStorage.setItem(key, value)
  }
}

const getThemePreference = (key: string, defaultValue: string): string => {
  if (typeof window !== "undefined") {
    return localStorage.getItem(key) || defaultValue
  }
  return defaultValue
}

export function useThemeCustomizer() {
  const { theme, setTheme } = useTheme()
  const { toast } = useToast()
  const [mounted, setMounted] = useState(false)
  const [colorTheme, setColorTheme] = useState<ColorTheme>("blue")
  const [fontSize, setFontSize] = useState<FontSize>("medium")

  // تحميل التفضيلات المخزنة
  useEffect(() => {
    setMounted(true)
    const storedColorTheme = getThemePreference("color-theme", "blue") as ColorTheme
    const storedFontSize = getThemePreference("font-size", "medium") as FontSize

    setColorTheme(storedColorTheme)
    setFontSize(storedFontSize)

    // تطبيق التفضيلات المخزنة
    applyColorTheme(storedColorTheme)
    applyFontSize(storedFontSize)
  }, [])

  // تطبيق سمة الألوان
  const applyColorTheme = (theme: ColorTheme) => {
    const root = document.documentElement
    const colors = themeColors[theme]

    Object.entries(colors).forEach(([property, value]) => {
      root.style.setProperty(`--${property}`, value)
    })
  }

  // تطبيق حجم الخط
  const applyFontSize = (size: FontSize) => {
    const root = document.documentElement
    const sizes = fontSizes[size]

    root.style.setProperty("--font-size-base", sizes.base)
    root.style.setProperty("--font-size-heading", sizes.heading)

    // تطبيق حجم الخط على العناصر
    root.style.fontSize = sizes.base
  }

  // تغيير سمة الألوان
  const changeColorTheme = (newTheme: ColorTheme) => {
    setColorTheme(newTheme)
    applyColorTheme(newTheme)
    storeThemePreference("color-theme", newTheme)

    toast({
      title: "تم تغيير سمة الألوان",
      description: `تم تغيير سمة الألوان بنجاح`,
    })
  }

  // تغيير حجم الخط
  const changeFontSize = (newSize: FontSize) => {
    setFontSize(newSize)
    applyFontSize(newSize)
    storeThemePreference("font-size", newSize)

    toast({
      title: "تم تغيير حجم الخط",
      description: `تم تغيير حجم الخط بنجاح`,
    })
  }

  // تغيير الوضع المظلم/الفاتح
  const changeThemeMode = (mode: "light" | "dark") => {
    setTheme(mode)

    toast({
      title: "تم تغيير المظهر",
      description: `تم تغيير المظهر إلى الوضع ${mode === "dark" ? "المظلم" : "الفاتح"}`,
    })
  }

  return {
    mounted,
    theme,
    colorTheme,
    fontSize,
    changeThemeMode,
    changeColorTheme,
    changeFontSize,
  }
}

