"use client"

import type React from "react"

import { useState, useEffect } from "react"
import Link from "next/link"
import { usePathname } from "next/navigation"
import {
  BarChart3,
  Package,
  Users,
  FileText,
  Settings,
  Menu,
  X,
  LogOut,
  DollarSign,
  Home,
  Search,
  ShoppingCart,
  UserPlus,
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { useToast } from "@/hooks/use-toast"
import { useMobile } from "@/hooks/use-mobile"
import { Input } from "@/components/ui/input"
import { ThemeToggle } from "@/components/theme-toggle"

interface MainLayoutProps {
  children: React.ReactNode
}

export function MainLayout({ children }: MainLayoutProps) {
  const pathname = usePathname()
  const isMobile = useMobile()
  const [open, setOpen] = useState(false)
  const { toast } = useToast()

  // تحديث مصفوفة التنقل لإضافة رابط صفحة الموظفين
  const navigation = [
    { name: "لوحة التحكم", href: "/dashboard", icon: BarChart3 },
    { name: "المصروفات", href: "/expenses", icon: DollarSign },
    { name: "المخزن", href: "/inventory", icon: Package },
    { name: "الطلبات", href: "/orders", icon: ShoppingCart },
    { name: "العملاء", href: "/customers", icon: Users },
    { name: "الموظفين", href: "/employees", icon: UserPlus },
    { name: "التقارير", href: "/reports", icon: FileText },
    { name: "الإعدادات", href: "/settings", icon: Settings },
  ]

  const handleLogout = () => {
    toast({
      title: "تم تسجيل الخروج",
      description: "تم تسجيل خروجك بنجاح من النظام",
    })
  }

  useEffect(() => {
    if (open && !isMobile) {
      setOpen(false)
    }
  }, [isMobile])

  const NavItems = () => (
    <>
      <div className="px-3 py-4">
        <Link href="/" className="flex items-center gap-2 px-2">
          <div className="h-8 w-8 rounded-md bg-primary flex items-center justify-center text-primary-foreground">
            <Home className="h-5 w-5" />
          </div>
          <span className="font-bold text-xl text-gradient">إدارة المصنع</span>
        </Link>
      </div>
      <div className="px-3 py-2">
        <nav className="space-y-1.5">
          {navigation.map((item) => {
            const isActive = pathname === item.href
            return (
              <Link
                key={item.name}
                href={item.href}
                className={`flex items-center gap-3 rounded-lg px-3 py-2.5 text-sm font-medium transition-colors ${
                  isActive
                    ? "bg-primary text-primary-foreground shadow-md"
                    : "text-muted-foreground hover:bg-muted hover:text-foreground"
                }`}
              >
                <item.icon className={`h-5 w-5 ${isActive ? "animate-pulse-slow" : ""}`} />
                {item.name}
              </Link>
            )
          })}
        </nav>
      </div>
    </>
  )

  return (
    <div className="flex min-h-screen flex-col">
      <header className="sticky top-0 z-10 flex h-16 items-center gap-2 border-b bg-background/80 backdrop-blur-md px-3 md:px-6">
        <Sheet open={open} onOpenChange={setOpen}>
          <SheetTrigger asChild>
            <Button variant="outline" size="icon" className="md:hidden">
              <Menu className="h-5 w-5" />
              <span className="sr-only">فتح القائمة</span>
            </Button>
          </SheetTrigger>
          <SheetContent side="right" className="w-72 p-0 sm:max-w-full">
            <div className="grid gap-4 py-4">
              <div className="flex items-center justify-between px-4">
                <Link href="/" className="flex items-center gap-2">
                  <div className="h-8 w-8 rounded-md bg-primary flex items-center justify-center text-primary-foreground">
                    <Home className="h-5 w-5" />
                  </div>
                  <span className="font-bold text-xl text-gradient">إدارة المصنع</span>
                </Link>
                <Button variant="ghost" size="icon" onClick={() => setOpen(false)}>
                  <X className="h-5 w-5" />
                </Button>
              </div>
              <div className="px-3 py-2">
                <nav className="space-y-1.5">
                  {navigation.map((item) => {
                    const isActive = pathname === item.href
                    return (
                      <Link
                        key={item.name}
                        href={item.href}
                        onClick={() => setOpen(false)}
                        className={`flex items-center gap-3 rounded-lg px-3 py-3 text-sm font-medium transition-colors ${
                          isActive
                            ? "bg-primary text-primary-foreground shadow-md"
                            : "text-muted-foreground hover:bg-muted hover:text-foreground"
                        }`}
                      >
                        <item.icon className="h-5 w-5" />
                        {item.name}
                      </Link>
                    )
                  })}
                </nav>
              </div>
            </div>
          </SheetContent>
        </Sheet>
        <div className="flex-1 overflow-hidden">
          <h1 className="text-base font-semibold truncate md:text-xl">
            {navigation.find((item) => item.href === pathname)?.name || "الصفحة الرئيسية"}
          </h1>
        </div>
        <div className="flex items-center gap-2">
          <div className="relative md:hidden">
            <Button variant="ghost" size="icon" className="h-8 w-8">
              <Search className="h-4 w-4" />
            </Button>
          </div>
          <div className="hidden md:block relative w-full max-w-sm">
            <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
            <Input
              type="search"
              placeholder="بحث..."
              className="w-full bg-background shadow-none appearance-none pl-8 md:w-[200px] lg:w-[300px]"
            />
          </div>
          <ThemeToggle />
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" size="icon" className="rounded-full">
                <Avatar className="h-8 w-8">
                  <AvatarImage src="/placeholder-user.jpg" alt="صورة المستخدم" />
                  <AvatarFallback>م.م</AvatarFallback>
                </Avatar>
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuLabel>حسابي</DropdownMenuLabel>
              <DropdownMenuSeparator />
              <DropdownMenuItem>الملف الشخصي</DropdownMenuItem>
              <DropdownMenuItem>الإعدادات</DropdownMenuItem>
              <DropdownMenuSeparator />
              <DropdownMenuItem onClick={handleLogout}>
                <LogOut className="ml-2 h-4 w-4" />
                <span>تسجيل الخروج</span>
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </header>
      <div className="flex flex-1">
        <aside className="hidden w-64 border-l bg-muted/40 md:block">
          <div className="flex h-full flex-col">
            <NavItems />
          </div>
        </aside>
        <main className="flex-1 p-4 md:p-6">{children}</main>
      </div>
    </div>
  )
}

