"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { useToast } from "@/hooks/use-toast"
import { Plus, Loader2 } from "lucide-react"
import { useRouter } from "next/navigation"

export function AddOrderForm() {
  const [open, setOpen] = useState(false)
  const [loading, setLoading] = useState(false)
  const [formData, setFormData] = useState({
    customer_id: "",
    status: "قيد التنفيذ",
    total: "",
    order_date: new Date().toISOString().split("T")[0],
  })
  const { toast } = useToast()
  const router = useRouter()

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target
    setFormData((prev) => ({ ...prev, [name]: value }))
  }

  const handleSelectChange = (field: string, value: string) => {
    setFormData((prev) => ({ ...prev, [field]: value }))
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)

    try {
      // محاكاة إضافة طلب جديد
      await new Promise((resolve) => setTimeout(resolve, 1000))

      toast({
        title: "تمت الإضافة بنجاح",
        description: "تم إضافة الطلب بنجاح",
      })
      setOpen(false)
      setFormData({
        customer_id: "",
        status: "قيد التنفيذ",
        total: "",
        order_date: new Date().toISOString().split("T")[0],
      })
      router.refresh()
    } catch (error) {
      toast({
        title: "حدث خطأ",
        description: "لم يتم إضافة الطلب، يرجى المحاولة مرة أخرى",
        variant: "destructive",
      })
    } finally {
      setLoading(false)
    }
  }

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button className="flex items-center gap-1 w-full sm:w-auto justify-center">
          <Plus className="h-4 w-4" />
          <span>إضافة طلب</span>
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-[425px]">
        <DialogHeader>
          <DialogTitle>إضافة طلب جديد</DialogTitle>
          <DialogDescription>أدخل تفاصيل الطلب الجديد هنا. اضغط على حفظ عند الانتهاء.</DialogDescription>
        </DialogHeader>
        <form onSubmit={handleSubmit}>
          <div className="grid gap-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="customer_id">العميل</Label>
              <Select
                value={formData.customer_id}
                onValueChange={(value) => handleSelectChange("customer_id", value)}
                required
              >
                <SelectTrigger id="customer_id">
                  <SelectValue placeholder="اختر العميل" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="1">أحمد محمد</SelectItem>
                  <SelectItem value="2">سارة أحمد</SelectItem>
                  <SelectItem value="3">محمد علي</SelectItem>
                  <SelectItem value="4">فاطمة حسن</SelectItem>
                  <SelectItem value="5">خالد عبدالله</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label htmlFor="status">الحالة</Label>
              <Select value={formData.status} onValueChange={(value) => handleSelectChange("status", value)} required>
                <SelectTrigger id="status">
                  <SelectValue placeholder="اختر الحالة" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="قيد التنفيذ">قيد التنفيذ</SelectItem>
                  <SelectItem value="مكتمل">مكتمل</SelectItem>
                  <SelectItem value="ملغي">ملغي</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label htmlFor="total">المبلغ الإجمالي</Label>
              <Input
                id="total"
                name="total"
                type="number"
                value={formData.total}
                onChange={handleChange}
                placeholder="المبلغ الإجمالي"
                required
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="order_date">تاريخ الطلب</Label>
              <Input
                id="order_date"
                name="order_date"
                type="date"
                value={formData.order_date}
                onChange={handleChange}
                required
              />
            </div>
          </div>
          <DialogFooter>
            <Button type="submit" disabled={loading}>
              {loading ? (
                <>
                  <Loader2 className="ml-2 h-4 w-4 animate-spin" />
                  جاري الحفظ...
                </>
              ) : (
                "حفظ"
              )}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  )
}

