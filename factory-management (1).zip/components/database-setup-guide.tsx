"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { AlertCircle, CheckCircle2, Copy, Database, ExternalLink } from "lucide-react"
import { useToast } from "@/hooks/use-toast"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

export function DatabaseSetupGuide() {
  const [showGuide, setShowGuide] = useState(true)
  const { toast } = useToast()

  const handleCopySQL = (sql: string) => {
    navigator.clipboard.writeText(sql)
    toast({
      title: "تم النسخ",
      description: "تم نسخ SQL إلى الحافظة",
    })
  }

  const handleCopyEnv = (env: string) => {
    navigator.clipboard.writeText(env)
    toast({
      title: "تم النسخ",
      description: "تم نسخ متغيرات البيئة إلى الحافظة",
    })
  }

  if (!showGuide) return null

  return (
    <Card className="mb-6">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Database className="h-5 w-5" />
          <span>إعداد قاعدة البيانات</span>
        </CardTitle>
        <CardDescription>يجب إعداد قاعدة البيانات في Supabase قبل استخدام التطبيق</CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <Alert variant="warning">
          <AlertCircle className="h-4 w-4" />
          <AlertTitle>تنبيه</AlertTitle>
          <AlertDescription>
            لم يتم العثور على متغيرات البيئة الخاصة بـ Supabase أو جداول قاعدة البيانات. يرجى اتباع الخطوات التالية
            لإعداد التطبيق.
          </AlertDescription>
        </Alert>

        <Tabs defaultValue="env">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="env">متغيرات البيئة</TabsTrigger>
            <TabsTrigger value="database">قاعدة البيانات</TabsTrigger>
          </TabsList>

          <TabsContent value="env" className="space-y-4 mt-4">
            <div>
              <h3 className="text-lg font-medium mb-2">الخطوة 1: إنشاء مشروع Supabase</h3>
              <p className="text-sm text-muted-foreground mb-2">
                قم بإنشاء مشروع جديد في Supabase إذا لم يكن لديك مشروع بالفعل.
              </p>
              <Button variant="outline" size="sm" className="gap-1" asChild>
                <a href="https://app.supabase.com" target="_blank" rel="noopener noreferrer">
                  <ExternalLink className="h-4 w-4" />
                  <span>فتح Supabase</span>
                </a>
              </Button>
            </div>

            <div>
              <h3 className="text-lg font-medium mb-2">الخطوة 2: الحصول على متغيرات البيئة</h3>
              <p className="text-sm text-muted-foreground mb-2">
                انتقل إلى إعدادات المشروع في Supabase واحصل على URL و Anon Key.
              </p>
              <ol className="list-decimal list-inside text-sm space-y-2 mb-2">
                <li>انتقل إلى لوحة تحكم مشروعك في Supabase</li>
                <li>انقر على رمز الترس ⚙️ في القائمة الجانبية للوصول إلى الإعدادات</li>
                <li>انتقل إلى قسم "API"</li>
                <li>انسخ "Project URL" و "anon public" من قسم "Project API keys"</li>
              </ol>
            </div>

            <div>
              <h3 className="text-lg font-medium mb-2">الخطوة 3: إضافة متغيرات البيئة إلى المشروع</h3>
              <p className="text-sm text-muted-foreground mb-2">
                أنشئ ملف .env.local في المجلد الرئيسي للمشروع وأضف المتغيرات التالية:
              </p>
              <div className="relative">
                <pre className="bg-muted p-4 rounded-md text-xs overflow-x-auto">
                  {`NEXT_PUBLIC_SUPABASE_URL=https://your-project-url.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=your-anon-key`}
                </pre>
                <Button
                  variant="ghost"
                  size="icon"
                  className="absolute top-2 right-2"
                  onClick={() =>
                    handleCopyEnv(`NEXT_PUBLIC_SUPABASE_URL=https://your-project-url.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=your-anon-key`)
                  }
                >
                  <Copy className="h-4 w-4" />
                </Button>
              </div>
              <p className="text-sm text-muted-foreground mt-2">استبدل القيم بالقيم الخاصة بمشروعك في Supabase.</p>
            </div>
          </TabsContent>

          <TabsContent value="database" className="space-y-4 mt-4">
            <div>
              <h3 className="text-lg font-medium mb-2">الخطوة 1: الوصول إلى SQL Editor في Supabase</h3>
              <p className="text-sm text-muted-foreground mb-2">
                قم بتسجيل الدخول إلى لوحة تحكم Supabase وانتقل إلى SQL Editor.
              </p>
              <Button variant="outline" size="sm" className="gap-1" asChild>
                <a href="https://app.supabase.com" target="_blank" rel="noopener noreferrer">
                  <ExternalLink className="h-4 w-4" />
                  <span>فتح Supabase</span>
                </a>
              </Button>
            </div>

            <div>
              <h3 className="text-lg font-medium mb-2">الخطوة 2: إنشاء الجداول</h3>
              <p className="text-sm text-muted-foreground mb-2">انسخ والصق SQL التالي في SQL Editor وقم بتنفيذه.</p>
              <div className="relative">
                <pre className="bg-muted p-4 rounded-md text-xs overflow-x-auto max-h-40 overflow-y-auto">
                  {`-- Create expenses table
CREATE TABLE IF NOT EXISTS expenses (
id SERIAL PRIMARY KEY,
description TEXT NOT NULL,
category TEXT NOT NULL,
amount DECIMAL(10, 2) NOT NULL,
date DATE NOT NULL,
created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create inventory table
CREATE TABLE IF NOT EXISTS inventory (
id SERIAL PRIMARY KEY,
code TEXT NOT NULL UNIQUE,
name TEXT NOT NULL,
category TEXT NOT NULL,
quantity INTEGER NOT NULL DEFAULT 0,
price DECIMAL(10, 2) NOT NULL,
status TEXT NOT NULL,
created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create customers table
CREATE TABLE IF NOT EXISTS customers (
id SERIAL PRIMARY KEY,
name TEXT NOT NULL,
email TEXT NOT NULL UNIQUE,
phone TEXT NOT NULL,
orders INTEGER NOT NULL DEFAULT 0,
total DECIMAL(10, 2) NOT NULL DEFAULT 0,
created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create orders table
CREATE TABLE IF NOT EXISTS orders (
id SERIAL PRIMARY KEY,
customer_id INTEGER NOT NULL,
order_date DATE NOT NULL,
status TEXT NOT NULL,
total DECIMAL(10, 2) NOT NULL,
created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
CONSTRAINT fk_customer
  FOREIGN KEY(customer_id)
  REFERENCES customers(id)
  ON DELETE CASCADE
);

-- Create order_items table
CREATE TABLE IF NOT EXISTS order_items (
id SERIAL PRIMARY KEY,
order_id INTEGER NOT NULL,
product_id INTEGER NOT NULL,
quantity INTEGER NOT NULL,
price DECIMAL(10, 2) NOT NULL,
created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
CONSTRAINT fk_order
  FOREIGN KEY(order_id)
  REFERENCES orders(id)
  ON DELETE CASCADE,
CONSTRAINT fk_product
  FOREIGN KEY(product_id)
  REFERENCES inventory(id)
  ON DELETE CASCADE
);

-- Create indexes
CREATE INDEX IF NOT EXISTS expenses_date_idx ON expenses(date);
CREATE INDEX IF NOT EXISTS inventory_category_idx ON inventory(category);
CREATE INDEX IF NOT EXISTS customers_email_idx ON customers(email);
CREATE INDEX IF NOT EXISTS orders_customer_id_idx ON orders(customer_id);
CREATE INDEX IF NOT EXISTS order_items_order_id_idx ON order_items(order_id);
CREATE INDEX IF NOT EXISTS order_items_product_id_idx ON order_items(product_id);`}
                </pre>
                <Button
                  variant="ghost"
                  size="icon"
                  className="absolute top-2 right-2"
                  onClick={() =>
                    handleCopySQL(`-- Create expenses table
CREATE TABLE IF NOT EXISTS expenses (
id SERIAL PRIMARY KEY,
description TEXT NOT NULL,
category TEXT NOT NULL,
amount DECIMAL(10, 2) NOT NULL,
date DATE NOT NULL,
created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create inventory table
CREATE TABLE IF NOT EXISTS inventory (
id SERIAL PRIMARY KEY,
code TEXT NOT NULL UNIQUE,
name TEXT NOT NULL,
category TEXT NOT NULL,
quantity INTEGER NOT NULL DEFAULT 0,
price DECIMAL(10, 2) NOT NULL,
status TEXT NOT NULL,
created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create customers table
CREATE TABLE IF NOT EXISTS customers (
id SERIAL PRIMARY KEY,
name TEXT NOT NULL,
email TEXT NOT NULL UNIQUE,
phone TEXT NOT NULL,
orders INTEGER NOT NULL DEFAULT 0,
total DECIMAL(10, 2) NOT NULL DEFAULT 0,
created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create orders table
CREATE TABLE IF NOT EXISTS orders (
id SERIAL PRIMARY KEY,
customer_id INTEGER NOT NULL,
order_date DATE NOT NULL,
status TEXT NOT NULL,
total DECIMAL(10, 2) NOT NULL,
created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
CONSTRAINT fk_customer
  FOREIGN KEY(customer_id)
  REFERENCES customers(id)
  ON DELETE CASCADE
);

-- Create order_items table
CREATE TABLE IF NOT EXISTS order_items (
id SERIAL PRIMARY KEY,
order_id INTEGER NOT NULL,
product_id INTEGER NOT NULL,
quantity INTEGER NOT NULL,
price DECIMAL(10, 2) NOT NULL,
created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
CONSTRAINT fk_order
  FOREIGN KEY(order_id)
  REFERENCES orders(id)
  ON DELETE CASCADE,
CONSTRAINT fk_product
  FOREIGN KEY(product_id)
  REFERENCES inventory(id)
  ON DELETE CASCADE
);

-- Create indexes
CREATE INDEX IF NOT EXISTS expenses_date_idx ON expenses(date);
CREATE INDEX IF NOT EXISTS inventory_category_idx ON inventory(category);
CREATE INDEX IF NOT EXISTS customers_email_idx ON customers(email);
CREATE INDEX IF NOT EXISTS orders_customer_id_idx ON orders(customer_id);
CREATE INDEX IF NOT EXISTS order_items_order_id_idx ON order_items(order_id);
CREATE INDEX IF NOT EXISTS order_items_product_id_idx ON order_items(product_id);`)
                  }
                >
                  <Copy className="h-4 w-4" />
                </Button>
              </div>
            </div>

            <div>
              <h3 className="text-lg font-medium mb-2">الخطوة 3: إدخال بيانات تجريبية</h3>
              <p className="text-sm text-muted-foreground mb-2">
                انسخ والصق SQL التالي في SQL Editor وقم بتنفيذه لإدخال بيانات تجريبية.
              </p>
              <div className="relative">
                <pre className="bg-muted p-4 rounded-md text-xs overflow-x-auto max-h-40 overflow-y-auto">
                  {`-- Seed expenses
INSERT INTO expenses (description, category, amount, date)
VALUES
('فواتير الكهرباء', 'مرافق', 2500, '2023-05-12'),
('رواتب الموظفين', 'رواتب', 15000, '2023-05-10'),
('شراء مواد خام', 'مواد خام', 7800, '2023-05-08'),
('صيانة المعدات', 'صيانة', 1200, '2023-05-05'),
('فواتير المياه', 'مرافق', 800, '2023-05-03');

-- Seed inventory
INSERT INTO inventory (code, name, category, quantity, price, status)
VALUES
('P001', 'منتج أ', 'فئة 1', 150, 250, 'متوفر'),
('P002', 'منتج ب', 'فئة 2', 75, 320, 'متوفر'),
('P003', 'منتج ج', 'فئة 1', 5, 180, 'منخفض'),
('P004', 'منتج د', 'فئة 3', 0, 420, 'غير متوفر'),
('P005', 'منتج هـ', 'فئة 2', 200, 150, 'متوفر');

-- Seed customers
INSERT INTO customers (name, email, phone, orders, total)
VALUES
('أحمد محمد', 'ahmed@example.com', '01012345678', 12, 15600),
('سارة أحمد', 'sara@example.com', '01123456789', 8, 9200),
('محمد علي', 'mohamed@example.com', '01234567890', 15, 18500),
('فاطمة حسن', 'fatma@example.com', '01198765432', 5, 4800),
('خالد عبدالله', 'khaled@example.com', '01087654321', 20, 25000);

-- Seed orders
INSERT INTO orders (customer_id, order_date, status, total)
VALUES
(1, '2023-05-15', 'مكتمل', 1500),
(2, '2023-05-14', 'مكتمل', 2200),
(3, '2023-05-13', 'قيد التنفيذ', 3500),
(4, '2023-05-12', 'مكتمل', 1800),
(5, '2023-05-11', 'ملغي', 2500);

-- Seed order_items
INSERT INTO order_items (order_id, product_id, quantity, price)
VALUES
(1, 1, 2, 500),
(1, 3, 3, 540),
(2, 2, 4, 1280),
(2, 5, 5, 750),
(3, 1, 6, 1500),
(3, 4, 2, 840),
(4, 3, 10, 1800),
(5, 5, 10, 1500),
(5, 2, 3, 960);`}
                </pre>
                <Button
                  variant="ghost"
                  size="icon"
                  className="absolute top-2 right-2"
                  onClick={() =>
                    handleCopySQL(`-- Seed expenses
INSERT INTO expenses (description, category, amount, date)
VALUES
('فواتير الكهرباء', 'مرافق', 2500, '2023-05-12'),
('رواتب الموظفين', 'رواتب', 15000, '2023-05-10'),
('شراء مواد خام', 'مواد خام', 7800, '2023-05-08'),
('صيانة المعدات', 'صيانة', 1200, '2023-05-05'),
('فواتير المياه', 'مرافق', 800, '2023-05-03');

-- Seed inventory
INSERT INTO inventory (code, name, category, quantity, price, status)
VALUES
('P001', 'منتج أ', 'فئة 1', 150, 250, 'متوفر'),
('P002', 'منتج ب', 'فئة 2', 75, 320, 'متوفر'),
('P003', 'منتج ج', 'فئة 1', 5, 180, 'منخفض'),
('P004', 'منتج د', 'فئة 3', 0, 420, 'غير متوفر'),
('P005', 'منتج هـ', 'فئة 2', 200, 150, 'متوفر');

-- Seed customers
INSERT INTO customers (name, email, phone, orders, total)
VALUES
('أحمد محمد', 'ahmed@example.com', '01012345678', 12, 15600),
('سارة أحمد', 'sara@example.com', '01123456789', 8, 9200),
('محمد علي', 'mohamed@example.com', '01234567890', 15, 18500),
('فاطمة حسن', 'fatma@example.com', '01198765432', 5, 4800),
('خالد عبدالله', 'khaled@example.com', '01087654321', 20, 25000);

-- Seed orders
INSERT INTO orders (customer_id, order_date, status, total)
VALUES
(1, '2023-05-15', 'مكتمل', 1500),
(2, '2023-05-14', 'مكتمل', 2200),
(3, '2023-05-13', 'قيد التنفيذ', 3500),
(4, '2023-05-12', 'مكتمل', 1800),
(5, '2023-05-11', 'ملغي', 2500);

-- Seed order_items
INSERT INTO order_items (order_id, product_id, quantity, price)
VALUES
(1, 1, 2, 500),
(1, 3, 3, 540),
(2, 2, 4, 1280),
(2, 5, 5, 750),
(3, 1, 6, 1500),
(3, 4, 2, 840),
(4, 3, 10, 1800),
(5, 5, 10, 1500),
(5, 2, 3, 960);`)
                  }
                >
                  <Copy className="h-4 w-4" />
                </Button>
              </div>
            </div>
          </TabsContent>
        </Tabs>
      </CardContent>
      <CardFooter className="flex justify-between">
        <Button variant="outline" onClick={() => setShowGuide(false)}>
          إغلاق
        </Button>
        <Button className="gap-1" onClick={() => window.location.reload()}>
          <CheckCircle2 className="h-4 w-4" />
          <span>تم الإعداد</span>
        </Button>
      </CardFooter>
    </Card>
  )
}

