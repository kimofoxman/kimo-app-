"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { useToast } from "@/hooks/use-toast"
import { Clock, Loader2 } from "lucide-react"
import { addAttendanceRecord, getEmployees } from "@/lib/api"
import { useRouter } from "next/navigation"
import { useEffect } from "react"

export function AttendanceForm() {
  const [open, setOpen] = useState(false)
  const [loading, setLoading] = useState(false)
  const [employees, setEmployees] = useState<any[]>([])
  const [formData, setFormData] = useState({
    employee_id: "",
    date: new Date().toISOString().split("T")[0],
    check_in: "",
    check_out: "",
    status: "في الوقت",
  })
  const { toast } = useToast()
  const router = useRouter()

  useEffect(() => {
    const fetchEmployees = async () => {
      try {
        const data = await getEmployees()
        setEmployees(data)
      } catch (error) {
        console.error("Error fetching employees:", error)
      }
    }

    if (open) {
      fetchEmployees()
    }
  }, [open])

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target
    setFormData((prev) => ({ ...prev, [name]: value }))
  }

  const handleSelectChange = (field: string, value: string) => {
    setFormData((prev) => ({ ...prev, [field]: value }))
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)

    try {
      // حساب ساعات العمل
      const checkIn = formData.check_in.split(":")
      const checkOut = formData.check_out.split(":")
      const checkInHour = Number.parseInt(checkIn[0])
      const checkInMinute = Number.parseInt(checkIn[1])
      const checkOutHour = Number.parseInt(checkOut[0])
      const checkOutMinute = Number.parseInt(checkOut[1])

      const workHours = checkOutHour - checkInHour + (checkOutMinute - checkInMinute) / 60

      // تحديد حالة الحضور (متأخر أو في الوقت)
      const status = checkInHour >= 9 ? "متأخر" : "في الوقت"

      // الحصول على اسم الموظف
      const employee = employees.find((e) => e.id === Number.parseInt(formData.employee_id))

      const record = await addAttendanceRecord({
        ...formData,
        employee_id: Number.parseInt(formData.employee_id),
        employee_name: employee?.name || "",
        work_hours: Number.parseFloat(workHours.toFixed(2)),
        status,
      })

      if (record) {
        toast({
          title: "تم التسجيل بنجاح",
          description: "تم تسجيل الحضور والانصراف بنجاح",
        })
        setOpen(false)
        setFormData({
          employee_id: "",
          date: new Date().toISOString().split("T")[0],
          check_in: "",
          check_out: "",
          status: "في الوقت",
        })
        router.refresh()
      }
    } catch (error) {
      toast({
        title: "حدث خطأ",
        description: "لم يتم تسجيل الحضور والانصراف، يرجى المحاولة مرة أخرى",
        variant: "destructive",
      })
    } finally {
      setLoading(false)
    }
  }

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button variant="outline" className="flex items-center gap-1">
          <Clock className="h-4 w-4" />
          <span>تسجيل حضور/انصراف</span>
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-[425px]">
        <DialogHeader>
          <DialogTitle>تسجيل الحضور والانصراف</DialogTitle>
          <DialogDescription>سجل حضور وانصراف الموظف. اضغط على حفظ عند الانتهاء.</DialogDescription>
        </DialogHeader>
        <form onSubmit={handleSubmit}>
          <div className="grid gap-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="employee_id">الموظف</Label>
              <Select
                value={formData.employee_id}
                onValueChange={(value) => handleSelectChange("employee_id", value)}
                required
              >
                <SelectTrigger id="employee_id">
                  <SelectValue placeholder="اختر الموظف" />
                </SelectTrigger>
                <SelectContent>
                  {employees.map((employee) => (
                    <SelectItem key={employee.id} value={employee.id.toString()}>
                      {employee.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label htmlFor="date">التاريخ</Label>
              <Input id="date" name="date" type="date" value={formData.date} onChange={handleChange} required />
            </div>
            <div className="space-y-2">
              <Label htmlFor="check_in">وقت الحضور</Label>
              <Input
                id="check_in"
                name="check_in"
                type="time"
                value={formData.check_in}
                onChange={handleChange}
                required
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="check_out">وقت الانصراف</Label>
              <Input
                id="check_out"
                name="check_out"
                type="time"
                value={formData.check_out}
                onChange={handleChange}
                required
              />
            </div>
          </div>
          <DialogFooter>
            <Button type="submit" disabled={loading}>
              {loading ? (
                <>
                  <Loader2 className="ml-2 h-4 w-4 animate-spin" />
                  جاري الحفظ...
                </>
              ) : (
                "حفظ"
              )}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  )
}

