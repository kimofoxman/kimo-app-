"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { useToast } from "@/hooks/use-toast"
import { Plus, Loader2 } from "lucide-react"
import { addInventoryItem } from "@/lib/api"
import { useRouter } from "next/navigation"

export function AddInventoryForm() {
  const [open, setOpen] = useState(false)
  const [loading, setLoading] = useState(false)
  const [formData, setFormData] = useState({
    code: "",
    name: "",
    category: "",
    quantity: "",
    price: "",
    status: "متوفر",
  })
  const { toast } = useToast()
  const router = useRouter()

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target
    setFormData((prev) => ({ ...prev, [name]: value }))
  }

  const handleSelectChange = (field: string, value: string) => {
    setFormData((prev) => ({ ...prev, [field]: value }))
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)

    try {
      // Determine status based on quantity
      let status = "متوفر"
      const quantity = Number.parseInt(formData.quantity)
      if (quantity === 0) {
        status = "غير متوفر"
      } else if (quantity <= 10) {
        status = "منخفض"
      }

      const item = await addInventoryItem({
        code: formData.code,
        name: formData.name,
        category: formData.category,
        quantity: Number.parseInt(formData.quantity),
        price: Number.parseFloat(formData.price),
        status,
      })

      if (item) {
        toast({
          title: "تمت الإضافة بنجاح",
          description: "تم إضافة المنتج بنجاح",
        })
        setOpen(false)
        setFormData({
          code: "",
          name: "",
          category: "",
          quantity: "",
          price: "",
          status: "متوفر",
        })
        router.refresh()
      }
    } catch (error) {
      toast({
        title: "حدث خطأ",
        description: "لم يتم إضافة المنتج، يرجى المحاولة مرة أخرى",
        variant: "destructive",
      })
    } finally {
      setLoading(false)
    }
  }

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button className="flex items-center gap-1 w-full sm:w-auto justify-center">
          <Plus className="h-4 w-4" />
          <span>إضافة منتج</span>
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-[425px]">
        <DialogHeader>
          <DialogTitle>إضافة منتج جديد</DialogTitle>
          <DialogDescription>أدخل تفاصيل المنتج الجديد هنا. اضغط على حفظ عند الانتهاء.</DialogDescription>
        </DialogHeader>
        <form onSubmit={handleSubmit}>
          <div className="grid gap-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="code">الكود</Label>
              <Input
                id="code"
                name="code"
                value={formData.code}
                onChange={handleChange}
                placeholder="كود المنتج"
                required
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="name">اسم المنتج</Label>
              <Input
                id="name"
                name="name"
                value={formData.name}
                onChange={handleChange}
                placeholder="اسم المنتج"
                required
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="category">الفئة</Label>
              <Select
                value={formData.category}
                onValueChange={(value) => handleSelectChange("category", value)}
                required
              >
                <SelectTrigger id="category">
                  <SelectValue placeholder="اختر الفئة" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="فئة 1">فئة 1</SelectItem>
                  <SelectItem value="فئة 2">فئة 2</SelectItem>
                  <SelectItem value="فئة 3">فئة 3</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label htmlFor="quantity">الكمية</Label>
              <Input
                id="quantity"
                name="quantity"
                type="number"
                value={formData.quantity}
                onChange={handleChange}
                placeholder="الكمية"
                required
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="price">سعر الوحدة</Label>
              <Input
                id="price"
                name="price"
                type="number"
                step="0.01"
                value={formData.price}
                onChange={handleChange}
                placeholder="سعر الوحدة"
                required
              />
            </div>
          </div>
          <DialogFooter>
            <Button type="submit" disabled={loading}>
              {loading ? (
                <>
                  <Loader2 className="ml-2 h-4 w-4 animate-spin" />
                  جاري الحفظ...
                </>
              ) : (
                "حفظ"
              )}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  )
}

