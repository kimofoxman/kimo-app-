"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { useToast } from "@/hooks/use-toast"
import { Eye, Loader2, DollarSign, Calendar, User } from "lucide-react"
import { getAttendance, processSalary } from "@/lib/api"

interface EmployeeDetailsProps {
  employee: {
    id: number
    name: string
    position: string
    department: string
    phone: string
    email: string
    salary: number
    join_date: string
    status: string
  }
}

export function EmployeeDetails({ employee }: EmployeeDetailsProps) {
  const [open, setOpen] = useState(false)
  const [loading, setLoading] = useState(false)
  const [processingPayroll, setProcessingPayroll] = useState(false)
  const [attendance, setAttendance] = useState<any[]>([])
  const [salary, setSalary] = useState<any | null>(null)
  const { toast } = useToast()

  useEffect(() => {
    const fetchAttendance = async () => {
      try {
        setLoading(true)
        const data = await getAttendance(employee.id)
        setAttendance(data)
      } catch (error) {
        console.error("Error fetching attendance:", error)
      } finally {
        setLoading(false)
      }
    }

    if (open) {
      fetchAttendance()
    }
  }, [open, employee.id])

  const handleProcessSalary = async () => {
    try {
      setProcessingPayroll(true)
      const data = await processSalary(employee.id)
      setSalary(data)

      toast({
        title: "تم معالجة الراتب",
        description: "تم معالجة راتب الموظف بنجاح",
      })
    } catch (error) {
      toast({
        title: "حدث خطأ",
        description: "لم يتم معالجة الراتب، يرجى المحاولة مرة أخرى",
        variant: "destructive",
      })
    } finally {
      setProcessingPayroll(false)
    }
  }

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button variant="ghost" size="icon" className="h-8 w-8">
          <Eye className="h-4 w-4" />
          <span className="sr-only">عرض التفاصيل</span>
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-[800px]">
        <DialogHeader>
          <DialogTitle>تفاصيل الموظف</DialogTitle>
          <DialogDescription>عرض بيانات الموظف وسجل الحضور والراتب</DialogDescription>
        </DialogHeader>

        <Tabs defaultValue="info" className="mt-4">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="info" className="flex items-center gap-2">
              <User className="h-4 w-4" />
              <span>البيانات الشخصية</span>
            </TabsTrigger>
            <TabsTrigger value="attendance" className="flex items-center gap-2">
              <Calendar className="h-4 w-4" />
              <span>سجل الحضور</span>
            </TabsTrigger>
            <TabsTrigger value="salary" className="flex items-center gap-2">
              <DollarSign className="h-4 w-4" />
              <span>الراتب</span>
            </TabsTrigger>
          </TabsList>

          <TabsContent value="info" className="mt-4">
            <Card>
              <CardHeader>
                <CardTitle>البيانات الشخصية</CardTitle>
                <CardDescription>معلومات الموظف الأساسية</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <h4 className="text-sm font-medium text-muted-foreground">الاسم</h4>
                    <p className="text-base">{employee.name}</p>
                  </div>
                  <div>
                    <h4 className="text-sm font-medium text-muted-foreground">المسمى الوظيفي</h4>
                    <p className="text-base">{employee.position}</p>
                  </div>
                  <div>
                    <h4 className="text-sm font-medium text-muted-foreground">القسم</h4>
                    <p className="text-base">{employee.department}</p>
                  </div>
                  <div>
                    <h4 className="text-sm font-medium text-muted-foreground">رقم الهاتف</h4>
                    <p className="text-base">{employee.phone}</p>
                  </div>
                  <div>
                    <h4 className="text-sm font-medium text-muted-foreground">البريد الإلكتروني</h4>
                    <p className="text-base">{employee.email}</p>
                  </div>
                  <div>
                    <h4 className="text-sm font-medium text-muted-foreground">تاريخ التعيين</h4>
                    <p className="text-base">{new Date(employee.join_date).toLocaleDateString("ar-EG")}</p>
                  </div>
                  <div>
                    <h4 className="text-sm font-medium text-muted-foreground">الراتب الأساسي</h4>
                    <p className="text-base">{employee.salary.toLocaleString()} ج.م</p>
                  </div>
                  <div>
                    <h4 className="text-sm font-medium text-muted-foreground">الحالة</h4>
                    <Badge
                      variant={
                        employee.status === "نشط" ? "default" : employee.status === "إجازة" ? "warning" : "destructive"
                      }
                      className="mt-1"
                    >
                      {employee.status}
                    </Badge>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="attendance" className="mt-4">
            <Card>
              <CardHeader>
                <CardTitle>سجل الحضور</CardTitle>
                <CardDescription>سجل حضور وانصراف الموظف</CardDescription>
              </CardHeader>
              <CardContent>
                {loading ? (
                  <div className="flex justify-center items-center h-40">
                    <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
                  </div>
                ) : (
                  <div className="overflow-x-auto">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>التاريخ</TableHead>
                          <TableHead>الحضور</TableHead>
                          <TableHead>الانصراف</TableHead>
                          <TableHead>ساعات العمل</TableHead>
                          <TableHead>الحالة</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {attendance.slice(0, 10).map((record) => (
                          <TableRow key={record.id}>
                            <TableCell>{new Date(record.date).toLocaleDateString("ar-EG")}</TableCell>
                            <TableCell>{record.check_in}</TableCell>
                            <TableCell>{record.check_out}</TableCell>
                            <TableCell>{record.work_hours}</TableCell>
                            <TableCell>
                              <Badge
                                variant={record.status === "في الوقت" ? "default" : "destructive"}
                                className="whitespace-nowrap"
                              >
                                {record.status}
                              </Badge>
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="salary" className="mt-4">
            <Card>
              <CardHeader>
                <CardTitle>الراتب</CardTitle>
                <CardDescription>تفاصيل راتب الموظف</CardDescription>
              </CardHeader>
              <CardContent>
                {salary ? (
                  <div className="space-y-4">
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      <div>
                        <h4 className="text-sm font-medium text-muted-foreground">الشهر</h4>
                        <p className="text-base">{salary.month}</p>
                      </div>
                      <div>
                        <h4 className="text-sm font-medium text-muted-foreground">الراتب الأساسي</h4>
                        <p className="text-base">{salary.basic_salary.toLocaleString()} ج.م</p>
                      </div>
                      <div>
                        <h4 className="text-sm font-medium text-muted-foreground">أيام العمل</h4>
                        <p className="text-base">{salary.work_days} يوم</p>
                      </div>
                      <div>
                        <h4 className="text-sm font-medium text-muted-foreground">ساعات العمل</h4>
                        <p className="text-base">{salary.work_hours} ساعة</p>
                      </div>
                      <div>
                        <h4 className="text-sm font-medium text-muted-foreground">عدد أيام التأخير</h4>
                        <p className="text-base">{salary.late_count} يوم</p>
                      </div>
                      <div>
                        <h4 className="text-sm font-medium text-muted-foreground">الخصومات</h4>
                        <p className="text-base text-red-500">- {salary.deductions.toLocaleString()} ج.م</p>
                      </div>
                      <div>
                        <h4 className="text-sm font-medium text-muted-foreground">المكافآت</h4>
                        <p className="text-base text-green-500">+ {salary.bonus.toLocaleString()} ج.م</p>
                      </div>
                      <div>
                        <h4 className="text-sm font-medium text-muted-foreground">صافي الراتب</h4>
                        <p className="text-lg font-bold">{salary.net_salary.toLocaleString()} ج.م</p>
                      </div>
                    </div>

                    <div className="flex justify-between items-center p-3 rounded-lg bg-muted/50">
                      <div>
                        <h4 className="font-medium">حالة الدفع</h4>
                        <Badge variant={salary.status === "مدفوع" ? "success" : "warning"} className="mt-1">
                          {salary.status}
                        </Badge>
                      </div>
                      <div>
                        <h4 className="text-sm font-medium text-muted-foreground">تاريخ الدفع</h4>
                        <p className="text-sm">{new Date(salary.payment_date).toLocaleDateString("ar-EG")}</p>
                      </div>
                    </div>
                  </div>
                ) : (
                  <div className="flex flex-col items-center justify-center h-40 gap-4">
                    <p className="text-muted-foreground">لم يتم معالجة الراتب بعد</p>
                    <Button
                      onClick={handleProcessSalary}
                      disabled={processingPayroll}
                      className="flex items-center gap-2"
                    >
                      {processingPayroll ? (
                        <>
                          <Loader2 className="h-4 w-4 animate-spin" />
                          جاري المعالجة...
                        </>
                      ) : (
                        <>
                          <DollarSign className="h-4 w-4" />
                          معالجة الراتب
                        </>
                      )}
                    </Button>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </DialogContent>
    </Dialog>
  )
}

