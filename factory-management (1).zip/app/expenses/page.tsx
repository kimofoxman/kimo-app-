import { Suspense } from "react"
import { MainLayout } from "@/components/main-layout"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Search, Filter, Loader2 } from "lucide-react"
import { getExpenses } from "@/lib/api"
import { AddExpenseForm } from "@/components/add-expense-form"
import { AddCategoryForm } from "@/components/add-category-form"

async function ExpensesTable() {
  const expenses = await getExpenses()

  return (
    <div className="overflow-x-auto">
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead>الرقم</TableHead>
            <TableHead>الوصف</TableHead>
            <TableHead className="hidden sm:table-cell">الفئة</TableHead>
            <TableHead className="hidden md:table-cell">التاريخ</TableHead>
            <TableHead className="text-left">المبلغ</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {expenses.map((expense) => (
            <TableRow key={expense.id}>
              <TableCell>{expense.id}</TableCell>
              <TableCell className="max-w-[120px] truncate">{expense.description}</TableCell>
              <TableCell className="hidden sm:table-cell">{expense.category}</TableCell>
              <TableCell className="hidden md:table-cell">
                {new Date(expense.date).toLocaleDateString("ar-EG")}
              </TableCell>
              <TableCell className="text-left font-medium">{expense.amount.toLocaleString()} ج.م</TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </div>
  )
}

export default function ExpensesPage() {
  return (
    <MainLayout>
      <div className="flex flex-col gap-4">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div>
            <h2 className="text-xl sm:text-2xl font-bold tracking-tight">المصروفات</h2>
            <p className="text-muted-foreground">إدارة وتتبع مصروفات المصنع</p>
          </div>
          <div className="flex flex-col sm:flex-row gap-2">
            <AddCategoryForm />
            <AddExpenseForm />
          </div>
        </div>

        <Card>
          <CardHeader className="pb-3">
            <CardTitle>تصفية المصروفات</CardTitle>
            <CardDescription>يمكنك تصفية المصروفات حسب التاريخ والفئة</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex flex-col gap-4">
              <div className="space-y-2">
                <div className="text-sm font-medium">البحث</div>
                <div className="relative">
                  <Search className="absolute right-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                  <Input placeholder="البحث عن مصروف..." className="pr-8" />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4">
                <div className="space-y-2">
                  <div className="text-sm font-medium">الفئة</div>
                  <Select>
                    <SelectTrigger>
                      <SelectValue placeholder="اختر الفئة" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">الكل</SelectItem>
                      <SelectItem value="utilities">مرافق</SelectItem>
                      <SelectItem value="salaries">رواتب</SelectItem>
                      <SelectItem value="materials">مواد خام</SelectItem>
                      <SelectItem value="maintenance">صيانة</SelectItem>
                      <SelectItem value="other">أخرى</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <div className="text-sm font-medium">من تاريخ</div>
                  <Input type="date" />
                </div>
                <div className="space-y-2">
                  <div className="text-sm font-medium">إلى تاريخ</div>
                  <Input type="date" />
                </div>
                <div className="flex items-end">
                  <Button variant="outline" className="gap-1 w-full">
                    <Filter className="h-4 w-4" />
                    <span>تصفية</span>
                  </Button>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="overflow-hidden">
          <CardHeader>
            <CardTitle>قائمة المصروفات</CardTitle>
            <CardDescription>جميع مصروفات المصنع مرتبة من الأحدث إلى الأقدم</CardDescription>
          </CardHeader>
          <CardContent className="p-0">
            <Suspense
              fallback={
                <div className="flex justify-center items-center h-40">
                  <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
                </div>
              }
            >
              <ExpensesTable />
            </Suspense>
          </CardContent>
        </Card>
      </div>
    </MainLayout>
  )
}

