import { MainLayout } from "@/components/main-layout"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Download, FileText, BarChart, PieChart, LineChart } from "lucide-react"

export default function ReportsPage() {
  return (
    <MainLayout>
      <div className="flex flex-col gap-4">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div>
            <h2 className="text-xl sm:text-2xl font-bold tracking-tight">التقارير</h2>
            <p className="text-muted-foreground">تحليل وتصدير تقارير أداء المصنع</p>
          </div>
          <Button className="flex items-center gap-1 w-full sm:w-auto justify-center">
            <Download className="h-4 w-4" />
            <span>تصدير التقرير</span>
          </Button>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>فترة التقرير</CardTitle>
            <CardDescription>اختر الفترة الزمنية للتقرير</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex flex-col gap-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
                <div className="space-y-2">
                  <div className="text-sm font-medium">نوع التقرير</div>
                  <Select defaultValue="sales">
                    <SelectTrigger>
                      <SelectValue placeholder="اختر نوع التقرير" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="sales">تقرير المبيعات</SelectItem>
                      <SelectItem value="expenses">تقرير المصروفات</SelectItem>
                      <SelectItem value="inventory">تقرير المخزون</SelectItem>
                      <SelectItem value="customers">تقرير العملاء</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <div className="text-sm font-medium">الفترة</div>
                  <Select defaultValue="month">
                    <SelectTrigger>
                      <SelectValue placeholder="اختر الفترة" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="day">يومي</SelectItem>
                      <SelectItem value="week">أسبوعي</SelectItem>
                      <SelectItem value="month">شهري</SelectItem>
                      <SelectItem value="quarter">ربع سنوي</SelectItem>
                      <SelectItem value="year">سنوي</SelectItem>
                      <SelectItem value="custom">مخصص</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <div className="text-sm font-medium">تنسيق التصدير</div>
                  <Select defaultValue="pdf">
                    <SelectTrigger>
                      <SelectValue placeholder="اختر تنسيق التصدير" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="pdf">PDF</SelectItem>
                      <SelectItem value="excel">Excel</SelectItem>
                      <SelectItem value="csv">CSV</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        <Tabs defaultValue="charts" className="w-full">
          <TabsList className="w-full grid grid-cols-2">
            <TabsTrigger value="charts" className="flex items-center gap-2 py-2">
              <BarChart className="h-4 w-4" />
              <span>الرسوم البيانية</span>
            </TabsTrigger>
            <TabsTrigger value="data" className="flex items-center gap-2 py-2">
              <FileText className="h-4 w-4" />
              <span>البيانات</span>
            </TabsTrigger>
          </TabsList>

          <TabsContent value="charts" className="mt-4">
            <div className="grid gap-4 grid-cols-1 md:grid-cols-2">
              <Card>
                <CardHeader className="pb-2">
                  <div className="flex items-center justify-between">
                    <CardTitle className="text-base">المبيعات الشهرية</CardTitle>
                    <BarChart className="h-4 w-4 text-muted-foreground" />
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="h-[250px] flex items-center justify-center bg-muted/40 rounded-md">
                    <p className="text-muted-foreground">رسم بياني للمبيعات الشهرية</p>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="pb-2">
                  <div className="flex items-center justify-between">
                    <CardTitle className="text-base">توزيع المصروفات</CardTitle>
                    <PieChart className="h-4 w-4 text-muted-foreground" />
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="h-[250px] flex items-center justify-center bg-muted/40 rounded-md">
                    <p className="text-muted-foreground">رسم بياني لتوزيع المصروفات</p>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="pb-2">
                  <div className="flex items-center justify-between">
                    <CardTitle className="text-base">اتجاهات المبيعات</CardTitle>
                    <LineChart className="h-4 w-4 text-muted-foreground" />
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="h-[250px] flex items-center justify-center bg-muted/40 rounded-md">
                    <p className="text-muted-foreground">رسم بياني لاتجاهات المبيعات</p>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="pb-2">
                  <div className="flex items-center justify-between">
                    <CardTitle className="text-base">أداء المنتجات</CardTitle>
                    <BarChart className="h-4 w-4 text-muted-foreground" />
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="h-[250px] flex items-center justify-center bg-muted/40 rounded-md">
                    <p className="text-muted-foreground">رسم بياني لأداء المنتجات</p>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="data" className="mt-4">
            <Card>
              <CardHeader>
                <CardTitle>بيانات التقرير</CardTitle>
                <CardDescription>عرض البيانات التفصيلية للتقرير المختار</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-[400px] sm:h-[600px] flex items-center justify-center bg-muted/40 rounded-md">
                  <p className="text-muted-foreground">سيتم عرض بيانات التقرير هنا</p>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </MainLayout>
  )
}

