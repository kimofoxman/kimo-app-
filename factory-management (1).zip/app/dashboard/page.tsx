import { Suspense } from "react"
import { MainLayout } from "@/components/main-layout"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { BarChart3, DollarSign, Package, Users, TrendingUp, TrendingDown, Loader2 } from "lucide-react"
import { getDashboardStats, getRecentOrders } from "@/lib/api"

async function DashboardStats() {
  const stats = await getDashboardStats()

  return (
    <div className="grid gap-4 grid-cols-1 sm:grid-cols-2 lg:grid-cols-4">
      <Card className="card-hover card-gradient">
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-sm font-medium">إجمالي المبيعات</CardTitle>
          <div className="h-8 w-8 rounded-full bg-primary/20 flex items-center justify-center">
            <DollarSign className="h-4 w-4 text-primary" />
          </div>
        </CardHeader>
        <CardContent>
          <div className="text-2xl font-bold">{stats.totalSales.toLocaleString()} ج.م</div>
          <p className="text-xs text-muted-foreground flex items-center mt-1">
            <TrendingUp className="ml-1 h-4 w-4 text-green-500" />
            <span className="text-green-500">+20.1%</span> منذ الشهر الماضي
          </p>
        </CardContent>
      </Card>
      <Card className="card-hover card-gradient">
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-sm font-medium">المنتجات</CardTitle>
          <div className="h-8 w-8 rounded-full bg-primary/20 flex items-center justify-center">
            <Package className="h-4 w-4 text-primary" />
          </div>
        </CardHeader>
        <CardContent>
          <div className="text-2xl font-bold">+{stats.productsCount}</div>
          <p className="text-xs text-muted-foreground flex items-center mt-1">
            <TrendingUp className="ml-1 h-4 w-4 text-green-500" />
            <span className="text-green-500">+12.2%</span> منذ الشهر الماضي
          </p>
        </CardContent>
      </Card>
      <Card className="card-hover card-gradient">
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-sm font-medium">العملاء</CardTitle>
          <div className="h-8 w-8 rounded-full bg-primary/20 flex items-center justify-center">
            <Users className="h-4 w-4 text-primary" />
          </div>
        </CardHeader>
        <CardContent>
          <div className="text-2xl font-bold">+{stats.customersCount}</div>
          <p className="text-xs text-muted-foreground flex items-center mt-1">
            <TrendingUp className="ml-1 h-4 w-4 text-green-500" />
            <span className="text-green-500">+18.7%</span> منذ الشهر الماضي
          </p>
        </CardContent>
      </Card>
      <Card className="card-hover card-gradient">
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-sm font-medium">المصروفات</CardTitle>
          <div className="h-8 w-8 rounded-full bg-primary/20 flex items-center justify-center">
            <BarChart3 className="h-4 w-4 text-primary" />
          </div>
        </CardHeader>
        <CardContent>
          <div className="text-2xl font-bold">{stats.totalExpenses.toLocaleString()} ج.م</div>
          <p className="text-xs text-muted-foreground flex items-center mt-1">
            <TrendingDown className="ml-1 h-4 w-4 text-red-500" />
            <span className="text-red-500">-4.5%</span> منذ الشهر الماضي
          </p>
        </CardContent>
      </Card>
    </div>
  )
}

async function RecentOrders() {
  const orders = await getRecentOrders()

  return (
    <div className="space-y-4">
      {orders.map((order) => (
        <div key={order.id} className="flex items-center gap-4 p-3 rounded-lg hover:bg-muted/50 transition-colors">
          <div className="w-10 h-10 sm:w-12 sm:h-12 rounded-md bg-primary/10 flex items-center justify-center">
            <Package className="h-5 w-5 sm:h-6 sm:w-6 text-primary" />
          </div>
          <div className="flex-1 space-y-1 min-w-0">
            <p className="text-sm font-medium truncate">طلب #{order.id}</p>
            <p className="text-xs text-muted-foreground">{order.customers.name}</p>
          </div>
          <div className="text-sm font-medium text-gradient-gold">{order.total.toLocaleString()} ج.م</div>
        </div>
      ))}
    </div>
  )
}

export default function DashboardPage() {
  return (
    <MainLayout>
      <div className="space-y-6">
        <div>
          <h2 className="text-2xl font-bold tracking-tight text-gradient mb-1">مرحبًا بك في لوحة التحكم</h2>
          <p className="text-muted-foreground">هذه نظرة عامة على أداء المصنع والإحصائيات الرئيسية</p>
        </div>

        <Suspense
          fallback={
            <div className="flex justify-center items-center h-40">
              <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
            </div>
          }
        >
          <DashboardStats />
        </Suspense>

        <div className="grid gap-4 grid-cols-1 lg:grid-cols-7">
          <Card className="lg:col-span-4 card-hover">
            <CardHeader>
              <CardTitle>نظرة عامة على المبيعات</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="h-[250px] sm:h-[300px] flex items-center justify-center bg-muted/40 rounded-md">
                <p className="text-muted-foreground">مخطط المبيعات سيظهر هنا</p>
              </div>
            </CardContent>
          </Card>
          <Card className="lg:col-span-3 card-hover">
            <CardHeader>
              <CardTitle>أحدث الطلبات</CardTitle>
            </CardHeader>
            <CardContent>
              <Suspense
                fallback={
                  <div className="flex justify-center items-center h-40">
                    <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
                  </div>
                }
              >
                <RecentOrders />
              </Suspense>
            </CardContent>
          </Card>
        </div>
      </div>
    </MainLayout>
  )
}

