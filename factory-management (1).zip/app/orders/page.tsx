import { Suspense } from "react"
import { MainLayout } from "@/components/main-layout"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Badge } from "@/components/ui/badge"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Search, Filter, Loader2, Eye } from "lucide-react"
import { getMockRecentOrders } from "@/lib/mock-data"
import { AddOrderForm } from "@/components/add-order-form"

async function OrdersTable() {
  const orders = await getMockRecentOrders(10)

  return (
    <div className="overflow-x-auto">
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead>رقم الطلب</TableHead>
            <TableHead>العميل</TableHead>
            <TableHead className="hidden md:table-cell">التاريخ</TableHead>
            <TableHead className="hidden sm:table-cell">الحالة</TableHead>
            <TableHead className="text-left">المبلغ</TableHead>
            <TableHead className="w-[50px]"></TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {orders.map((order) => (
            <TableRow key={order.id}>
              <TableCell>#{order.id}</TableCell>
              <TableCell className="max-w-[120px] truncate">{order.customers.name}</TableCell>
              <TableCell className="hidden md:table-cell">
                {new Date(order.order_date).toLocaleDateString("ar-EG")}
              </TableCell>
              <TableCell className="hidden sm:table-cell">
                <Badge
                  variant={
                    order.status === "مكتمل" ? "success" : order.status === "قيد التنفيذ" ? "default" : "destructive"
                  }
                  className="whitespace-nowrap"
                >
                  {order.status}
                </Badge>
              </TableCell>
              <TableCell className="text-left font-medium">{order.total.toLocaleString()} ج.م</TableCell>
              <TableCell>
                <Button variant="ghost" size="icon" className="h-8 w-8">
                  <Eye className="h-4 w-4" />
                  <span className="sr-only">عرض التفاصيل</span>
                </Button>
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </div>
  )
}

export default function OrdersPage() {
  return (
    <MainLayout>
      <div className="flex flex-col gap-4">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div>
            <h2 className="text-xl sm:text-2xl font-bold tracking-tight">الطلبات</h2>
            <p className="text-muted-foreground">إدارة طلبات العملاء ومتابعة حالتها</p>
          </div>
          <AddOrderForm />
        </div>

        <Card>
          <CardHeader className="pb-3">
            <CardTitle>تصفية الطلبات</CardTitle>
            <CardDescription>يمكنك تصفية الطلبات حسب التاريخ والحالة</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex flex-col gap-4">
              <div className="space-y-2">
                <div className="text-sm font-medium">البحث</div>
                <div className="relative">
                  <Search className="absolute right-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                  <Input placeholder="البحث عن طلب..." className="pr-8" />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4">
                <div className="space-y-2">
                  <div className="text-sm font-medium">الحالة</div>
                  <Select>
                    <SelectTrigger>
                      <SelectValue placeholder="اختر الحالة" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">الكل</SelectItem>
                      <SelectItem value="completed">مكتمل</SelectItem>
                      <SelectItem value="processing">قيد التنفيذ</SelectItem>
                      <SelectItem value="cancelled">ملغي</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <div className="text-sm font-medium">من تاريخ</div>
                  <Input type="date" />
                </div>
                <div className="space-y-2">
                  <div className="text-sm font-medium">إلى تاريخ</div>
                  <Input type="date" />
                </div>
                <div className="flex items-end">
                  <Button variant="outline" className="gap-1 w-full">
                    <Filter className="h-4 w-4" />
                    <span>تصفية</span>
                  </Button>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="overflow-hidden">
          <CardHeader>
            <CardTitle>قائمة الطلبات</CardTitle>
            <CardDescription>جميع طلبات العملاء مرتبة من الأحدث إلى الأقدم</CardDescription>
          </CardHeader>
          <CardContent className="p-0">
            <Suspense
              fallback={
                <div className="flex justify-center items-center h-40">
                  <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
                </div>
              }
            >
              <OrdersTable />
            </Suspense>
          </CardContent>
        </Card>
      </div>
    </MainLayout>
  )
}

