import { Suspense } from "react"
import { MainLayout } from "@/components/main-layout"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Badge } from "@/components/ui/badge"
import { Search, Loader2 } from "lucide-react"
import { getInventory, getLowStockItems } from "@/lib/api"
import { AddInventoryForm } from "@/components/add-inventory-form"
import { ProductDetails } from "@/components/product-details"

async function InventoryStats() {
  const inventory = await getInventory()
  const lowStockItems = await getLowStockItems()

  const totalItems = inventory.length
  const totalValue = inventory.reduce((sum, item) => sum + item.price * item.quantity, 0)
  const lowStockCount = lowStockItems.length

  return (
    <div className="grid gap-4 grid-cols-1 sm:grid-cols-2 md:grid-cols-3">
      <Card>
        <CardHeader className="pb-2">
          <CardTitle>إجمالي المنتجات</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-3xl font-bold">{totalItems}</div>
          <p className="text-sm text-muted-foreground mt-1">منتج في المخزن</p>
        </CardContent>
      </Card>
      <Card>
        <CardHeader className="pb-2">
          <CardTitle>قيمة المخزون</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-3xl font-bold">{totalValue.toLocaleString()} ج.م</div>
          <p className="text-sm text-muted-foreground mt-1">إجمالي قيمة المخزون</p>
        </CardContent>
      </Card>
      <Card>
        <CardHeader className="pb-2">
          <CardTitle>منتجات منخفضة</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-3xl font-bold text-red-500">{lowStockCount}</div>
          <p className="text-sm text-muted-foreground mt-1">منتج بحاجة إلى إعادة طلب</p>
        </CardContent>
      </Card>
    </div>
  )
}

async function InventoryTable() {
  const inventory = await getInventory()

  return (
    <div className="overflow-x-auto">
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead>الكود</TableHead>
            <TableHead>اسم المنتج</TableHead>
            <TableHead className="hidden md:table-cell">الفئة</TableHead>
            <TableHead className="text-left">الكمية</TableHead>
            <TableHead className="hidden sm:table-cell text-left">سعر الوحدة</TableHead>
            <TableHead>الحالة</TableHead>
            <TableHead className="w-[50px]"></TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {inventory.map((product) => (
            <TableRow key={product.id}>
              <TableCell>{product.code}</TableCell>
              <TableCell className="max-w-[120px] truncate">{product.name}</TableCell>
              <TableCell className="hidden md:table-cell">{product.category}</TableCell>
              <TableCell className="text-left">{product.quantity}</TableCell>
              <TableCell className="hidden sm:table-cell text-left">{product.price.toLocaleString()} ج.م</TableCell>
              <TableCell>
                <Badge
                  variant={
                    product.status === "متوفر" ? "default" : product.status === "منخفض" ? "warning" : "destructive"
                  }
                  className="whitespace-nowrap"
                >
                  {product.status}
                </Badge>
              </TableCell>
              <TableCell>
                <ProductDetails product={product} />
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </div>
  )
}

export default function InventoryPage() {
  return (
    <MainLayout>
      <div className="flex flex-col gap-4">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div>
            <h2 className="text-xl sm:text-2xl font-bold tracking-tight">المخزن</h2>
            <p className="text-muted-foreground">إدارة مخزون المنتجات والمواد الخام</p>
          </div>
          <AddInventoryForm />
        </div>

        <Suspense
          fallback={
            <div className="flex justify-center items-center h-40">
              <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
            </div>
          }
        >
          <InventoryStats />
        </Suspense>

        <Card className="overflow-hidden">
          <CardHeader>
            <div className="flex flex-col sm:flex-row sm:items-center gap-4">
              <div>
                <CardTitle>قائمة المنتجات</CardTitle>
                <CardDescription>جميع المنتجات المتوفرة في المخزن</CardDescription>
              </div>
              <div className="relative w-full sm:w-64 sm:ml-auto">
                <Search className="absolute right-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                <Input placeholder="البحث عن منتج..." className="pr-8" />
              </div>
            </div>
          </CardHeader>
          <CardContent className="p-0">
            <Suspense
              fallback={
                <div className="flex justify-center items-center h-40">
                  <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
                </div>
              }
            >
              <InventoryTable />
            </Suspense>
          </CardContent>
        </Card>
      </div>
    </MainLayout>
  )
}

