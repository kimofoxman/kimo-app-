import { MainLayout } from "@/components/main-layout"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { Plus, Search, MoreHorizontal } from "lucide-react"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"

export default function CustomersPage() {
  return (
    <MainLayout>
      <div className="flex flex-col gap-4">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div>
            <h2 className="text-xl sm:text-2xl font-bold tracking-tight">العملاء</h2>
            <p className="text-muted-foreground">إدارة قائمة العملاء والمعاملات</p>
          </div>
          <Button className="flex items-center gap-1 w-full sm:w-auto justify-center">
            <Plus className="h-4 w-4" />
            <span>إضافة عميل</span>
          </Button>
        </div>

        <div className="grid gap-4 grid-cols-1 sm:grid-cols-2 md:grid-cols-3">
          <Card>
            <CardHeader className="pb-2">
              <CardTitle>إجمالي العملاء</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold">249</div>
              <p className="text-sm text-muted-foreground mt-1">عميل نشط</p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="pb-2">
              <CardTitle>عملاء جدد</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold">24</div>
              <p className="text-sm text-muted-foreground mt-1">في الشهر الحالي</p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="pb-2">
              <CardTitle>متوسط قيمة الطلب</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold">1,250 ج.م</div>
              <p className="text-sm text-muted-foreground mt-1">لكل عميل</p>
            </CardContent>
          </Card>
        </div>

        <Card className="overflow-hidden">
          <CardHeader>
            <div className="flex flex-col sm:flex-row sm:items-center gap-4">
              <div>
                <CardTitle>قائمة العملاء</CardTitle>
                <CardDescription>جميع العملاء المسجلين في النظام</CardDescription>
              </div>
              <div className="relative w-full sm:w-64 sm:ml-auto">
                <Search className="absolute right-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                <Input placeholder="البحث عن عميل..." className="pr-8" />
              </div>
            </div>
          </CardHeader>
          <CardContent className="p-0">
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="w-[60px]"></TableHead>
                    <TableHead>الاسم</TableHead>
                    <TableHead className="hidden md:table-cell">البريد الإلكتروني</TableHead>
                    <TableHead className="hidden sm:table-cell">رقم الهاتف</TableHead>
                    <TableHead className="hidden sm:table-cell text-left">عدد الطلبات</TableHead>
                    <TableHead className="text-left">المشتريات</TableHead>
                    <TableHead className="w-[50px]"></TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {[
                    {
                      id: 1,
                      name: "أحمد محمد",
                      email: "ahmed@example.com",
                      phone: "01012345678",
                      orders: 12,
                      total: 15600,
                    },
                    {
                      id: 2,
                      name: "سارة أحمد",
                      email: "sara@example.com",
                      phone: "01123456789",
                      orders: 8,
                      total: 9200,
                    },
                    {
                      id: 3,
                      name: "محمد علي",
                      email: "mohamed@example.com",
                      phone: "01234567890",
                      orders: 15,
                      total: 18500,
                    },
                    {
                      id: 4,
                      name: "فاطمة حسن",
                      email: "fatma@example.com",
                      phone: "01198765432",
                      orders: 5,
                      total: 4800,
                    },
                    {
                      id: 5,
                      name: "خالد عبدالله",
                      email: "khaled@example.com",
                      phone: "01087654321",
                      orders: 20,
                      total: 25000,
                    },
                  ].map((customer) => (
                    <TableRow key={customer.id}>
                      <TableCell>
                        <Avatar className="h-8 w-8">
                          <AvatarFallback>{customer.name.substring(0, 2)}</AvatarFallback>
                        </Avatar>
                      </TableCell>
                      <TableCell className="font-medium max-w-[120px] truncate">{customer.name}</TableCell>
                      <TableCell className="hidden md:table-cell">{customer.email}</TableCell>
                      <TableCell className="hidden sm:table-cell">{customer.phone}</TableCell>
                      <TableCell className="hidden sm:table-cell text-left">{customer.orders}</TableCell>
                      <TableCell className="text-left font-medium">{customer.total} ج.م</TableCell>
                      <TableCell>
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button variant="ghost" size="icon" className="h-8 w-8">
                              <MoreHorizontal className="h-4 w-4" />
                              <span className="sr-only">خيارات</span>
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end">
                            <DropdownMenuItem>عرض التفاصيل</DropdownMenuItem>
                            <DropdownMenuItem>تعديل البيانات</DropdownMenuItem>
                            <DropdownMenuItem>سجل الطلبات</DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          </CardContent>
        </Card>
      </div>
    </MainLayout>
  )
}

