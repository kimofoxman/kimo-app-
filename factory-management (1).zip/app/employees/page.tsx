import { Suspense } from "react"
import { MainLayout } from "@/components/main-layout"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Badge } from "@/components/ui/badge"
import { Search, Loader2 } from "lucide-react"
import { getEmployees } from "@/lib/api"
import { AddEmployeeForm } from "@/components/add-employee-form"
import { AttendanceForm } from "@/components/attendance-form"
import { EmployeeDetails } from "@/components/employee-details"

async function EmployeesTable() {
  const employees = await getEmployees()

  return (
    <div className="overflow-x-auto">
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead>الاسم</TableHead>
            <TableHead className="hidden md:table-cell">المسمى الوظيفي</TableHead>
            <TableHead className="hidden sm:table-cell">القسم</TableHead>
            <TableHead className="hidden lg:table-cell">رقم الهاتف</TableHead>
            <TableHead className="hidden lg:table-cell">البريد الإلكتروني</TableHead>
            <TableHead className="text-left">الراتب</TableHead>
            <TableHead>الحالة</TableHead>
            <TableHead className="w-[50px]"></TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {employees.map((employee) => (
            <TableRow key={employee.id}>
              <TableCell className="font-medium">{employee.name}</TableCell>
              <TableCell className="hidden md:table-cell">{employee.position}</TableCell>
              <TableCell className="hidden sm:table-cell">{employee.department}</TableCell>
              <TableCell className="hidden lg:table-cell">{employee.phone}</TableCell>
              <TableCell className="hidden lg:table-cell">{employee.email}</TableCell>
              <TableCell className="text-left">{employee.salary.toLocaleString()} ج.م</TableCell>
              <TableCell>
                <Badge
                  variant={
                    employee.status === "نشط" ? "default" : employee.status === "إجازة" ? "warning" : "destructive"
                  }
                  className="whitespace-nowrap"
                >
                  {employee.status}
                </Badge>
              </TableCell>
              <TableCell>
                <EmployeeDetails employee={employee} />
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </div>
  )
}

export default function EmployeesPage() {
  return (
    <MainLayout>
      <div className="flex flex-col gap-4">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div>
            <h2 className="text-xl sm:text-2xl font-bold tracking-tight">الموظفين</h2>
            <p className="text-muted-foreground">إدارة بيانات الموظفين وسجلات الحضور والرواتب</p>
          </div>
          <div className="flex flex-col sm:flex-row gap-2">
            <AttendanceForm />
            <AddEmployeeForm />
          </div>
        </div>

        <div className="grid gap-4 grid-cols-1 sm:grid-cols-2 lg:grid-cols-4">
          <Card className="card-hover card-gradient">
            <CardHeader className="pb-2">
              <CardTitle>إجمالي الموظفين</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold">24</div>
              <p className="text-sm text-muted-foreground mt-1">موظف نشط</p>
            </CardContent>
          </Card>
          <Card className="card-hover card-gradient">
            <CardHeader className="pb-2">
              <CardTitle>إجمالي الرواتب</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold">120,500 ج.م</div>
              <p className="text-sm text-muted-foreground mt-1">شهريًا</p>
            </CardContent>
          </Card>
          <Card className="card-hover card-gradient">
            <CardHeader className="pb-2">
              <CardTitle>متوسط الراتب</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold">5,020 ج.م</div>
              <p className="text-sm text-muted-foreground mt-1">لكل موظف</p>
            </CardContent>
          </Card>
          <Card className="card-hover card-gradient">
            <CardHeader className="pb-2">
              <CardTitle>معدل الحضور</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold">92%</div>
              <p className="text-sm text-muted-foreground mt-1">هذا الشهر</p>
            </CardContent>
          </Card>
        </div>

        <Card className="overflow-hidden">
          <CardHeader>
            <div className="flex flex-col sm:flex-row sm:items-center gap-4">
              <div>
                <CardTitle>قائمة الموظفين</CardTitle>
                <CardDescription>جميع الموظفين المسجلين في النظام</CardDescription>
              </div>
              <div className="relative w-full sm:w-64 sm:ml-auto">
                <Search className="absolute right-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                <Input placeholder="البحث عن موظف..." className="pr-8" />
              </div>
            </div>
          </CardHeader>
          <CardContent className="p-0">
            <Suspense
              fallback={
                <div className="flex justify-center items-center h-40">
                  <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
                </div>
              }
            >
              <EmployeesTable />
            </Suspense>
          </CardContent>
        </Card>
      </div>
    </MainLayout>
  )
}

