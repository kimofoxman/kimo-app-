"use client"

import { MainLayout } from "@/components/main-layout"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Switch } from "@/components/ui/switch"
import { User, Building, Bell, Shield, Database, Save, Moon, Sun, Palette } from "lucide-react"
import { useThemeCustomizer, type FontSize } from "@/components/theme-customizer"
import { useToast } from "@/hooks/use-toast"
import { Slider } from "@/components/ui/slider"

export default function SettingsPage() {
  const { mounted, theme, colorTheme, fontSize, changeThemeMode, changeColorTheme, changeFontSize } =
    useThemeCustomizer()

  const { toast } = useToast()

  // تحويل حجم الخط إلى قيمة للسلايدر
  const fontSizeToSliderValue = (size: FontSize): number => {
    switch (size) {
      case "small":
        return 1
      case "medium":
        return 2
      case "large":
        return 3
      default:
        return 2
    }
  }

  // تحويل قيمة السلايدر إلى حجم الخط
  const sliderValueToFontSize = (value: number): FontSize => {
    switch (value) {
      case 1:
        return "small"
      case 2:
        return "medium"
      case 3:
        return "large"
      default:
        return "medium"
    }
  }

  const handleFontSizeChange = (value: number[]) => {
    const newSize = sliderValueToFontSize(value[0])
    changeFontSize(newSize)
  }

  const handleSaveSettings = () => {
    toast({
      title: "تم حفظ الإعدادات",
      description: "تم حفظ إعدادات المظهر بنجاح",
    })
  }

  return (
    <MainLayout>
      <div className="flex flex-col gap-4">
        <div>
          <h2 className="text-xl sm:text-2xl font-bold tracking-tight text-gradient">الإعدادات</h2>
          <p className="text-muted-foreground">إدارة إعدادات النظام والحساب</p>
        </div>

        <Tabs defaultValue="appearance">
          <div className="overflow-x-auto pb-2">
            <TabsList className="w-full max-w-full inline-flex bg-muted/60 p-1">
              <TabsTrigger
                value="profile"
                className="flex flex-col items-center gap-1 py-2 px-3 data-[state=active]:bg-background"
              >
                <User className="h-4 w-4" />
                <span className="text-xs">الملف الشخصي</span>
              </TabsTrigger>
              <TabsTrigger
                value="company"
                className="flex flex-col items-center gap-1 py-2 px-3 data-[state=active]:bg-background"
              >
                <Building className="h-4 w-4" />
                <span className="text-xs">المصنع</span>
              </TabsTrigger>
              <TabsTrigger
                value="notifications"
                className="flex flex-col items-center gap-1 py-2 px-3 data-[state=active]:bg-background"
              >
                <Bell className="h-4 w-4" />
                <span className="text-xs">الإشعارات</span>
              </TabsTrigger>
              <TabsTrigger
                value="security"
                className="flex flex-col items-center gap-1 py-2 px-3 data-[state=active]:bg-background"
              >
                <Shield className="h-4 w-4" />
                <span className="text-xs">الأمان</span>
              </TabsTrigger>
              <TabsTrigger
                value="system"
                className="flex flex-col items-center gap-1 py-2 px-3 data-[state=active]:bg-background"
              >
                <Database className="h-4 w-4" />
                <span className="text-xs">النظام</span>
              </TabsTrigger>
              <TabsTrigger
                value="appearance"
                className="flex flex-col items-center gap-1 py-2 px-3 data-[state=active]:bg-background"
              >
                <Palette className="h-4 w-4" />
                <span className="text-xs">المظهر</span>
              </TabsTrigger>
            </TabsList>
          </div>

          {/* محتوى التبويبات الأخرى يبقى كما هو */}
          <TabsContent value="profile" className="mt-4">
            {/* محتوى تبويب الملف الشخصي */}
          </TabsContent>

          <TabsContent value="company" className="mt-4">
            {/* محتوى تبويب المصنع */}
          </TabsContent>

          <TabsContent value="notifications" className="mt-4">
            {/* محتوى تبويب الإشعارات */}
          </TabsContent>

          <TabsContent value="security" className="mt-4">
            {/* محتوى تبويب الأمان */}
          </TabsContent>

          <TabsContent value="system" className="mt-4">
            {/* محتوى تبويب النظام */}
          </TabsContent>

          <TabsContent value="appearance" className="mt-4">
            <Card className="card-hover">
              <CardHeader>
                <CardTitle>إعدادات المظهر</CardTitle>
                <CardDescription>تخصيص مظهر التطبيق وألوانه</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                {mounted && (
                  <div className="space-y-6">
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 p-4 rounded-lg bg-gradient-to-r from-primary/10 to-primary/5 border">
                      <div>
                        <h4 className="font-medium">الوضع المظلم</h4>
                        <p className="text-sm text-muted-foreground">تبديل بين الوضع الفاتح والمظلم</p>
                      </div>
                      <div className="flex items-center gap-4">
                        <Button
                          variant={theme === "light" ? "default" : "outline"}
                          className="flex items-center gap-2 px-4"
                          onClick={() => changeThemeMode("light")}
                        >
                          <Sun className="h-5 w-5" />
                          <span>فاتح</span>
                        </Button>
                        <Button
                          variant={theme === "dark" ? "default" : "outline"}
                          className="flex items-center gap-2 px-4"
                          onClick={() => changeThemeMode("dark")}
                        >
                          <Moon className="h-5 w-5" />
                          <span>مظلم</span>
                        </Button>
                      </div>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div className="p-4 rounded-lg bg-gradient-to-br from-blue-500/10 to-blue-600/5 border hover:shadow-md transition-shadow">
                        <h4 className="font-medium mb-2">سمة الألوان</h4>
                        <div className="grid grid-cols-4 gap-2">
                          <button
                            className={`w-full aspect-square rounded-full bg-blue-500 cursor-pointer ${colorTheme === "blue" ? "ring-2 ring-offset-2 ring-blue-500" : ""}`}
                            onClick={() => changeColorTheme("blue")}
                            aria-label="سمة اللون الأزرق"
                          />
                          <button
                            className={`w-full aspect-square rounded-full bg-purple-500 cursor-pointer ${colorTheme === "purple" ? "ring-2 ring-offset-2 ring-purple-500" : ""}`}
                            onClick={() => changeColorTheme("purple")}
                            aria-label="سمة اللون البنفسجي"
                          />
                          <button
                            className={`w-full aspect-square rounded-full bg-green-500 cursor-pointer ${colorTheme === "green" ? "ring-2 ring-offset-2 ring-green-500" : ""}`}
                            onClick={() => changeColorTheme("green")}
                            aria-label="سمة اللون الأخضر"
                          />
                          <button
                            className={`w-full aspect-square rounded-full bg-amber-500 cursor-pointer ${colorTheme === "amber" ? "ring-2 ring-offset-2 ring-amber-500" : ""}`}
                            onClick={() => changeColorTheme("amber")}
                            aria-label="سمة اللون الكهرماني"
                          />
                        </div>
                      </div>

                      <div className="p-4 rounded-lg bg-gradient-to-br from-blue-500/10 to-blue-600/5 border hover:shadow-md transition-shadow">
                        <h4 className="font-medium mb-2">حجم الخط</h4>
                        <div className="space-y-4">
                          <div className="flex items-center justify-between">
                            <span className="text-xs">صغير</span>
                            <span className="text-lg">كبير</span>
                          </div>
                          <Slider
                            defaultValue={[fontSizeToSliderValue(fontSize)]}
                            max={3}
                            min={1}
                            step={1}
                            onValueChange={handleFontSizeChange}
                          />
                          <div className="text-center text-sm text-muted-foreground">
                            الحجم الحالي: {fontSize === "small" ? "صغير" : fontSize === "medium" ? "متوسط" : "كبير"}
                          </div>
                        </div>
                      </div>
                    </div>

                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 p-3 rounded-lg bg-muted/50 hover:bg-muted/70 transition-colors">
                      <div>
                        <h4 className="font-medium">تأثيرات الحركة</h4>
                        <p className="text-sm text-muted-foreground">تفعيل تأثيرات الحركة في التطبيق</p>
                      </div>
                      <Switch defaultChecked />
                    </div>
                  </div>
                )}
                <div className="flex justify-end">
                  <Button className="flex items-center gap-1 w-full sm:w-auto btn-glow" onClick={handleSaveSettings}>
                    <Save className="h-4 w-4" />
                    <span>حفظ التغييرات</span>
                  </Button>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </MainLayout>
  )
}

