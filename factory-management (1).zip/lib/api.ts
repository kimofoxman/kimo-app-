import { supabase } from "./supabase"
import type { Database } from "@/types/supabase"
import {
  getMockExpenses,
  getMockInventory,
  getMockCustomers,
  getMockDashboardStats,
  getMockRecentOrders,
  getMockLowStockItems,
  getMockEmployees,
  getMockAttendance,
  getMockSalaries,
} from "./mock-data"

// Types
export type Expense = Database["public"]["Tables"]["expenses"]["Row"]
export type Inventory = Database["public"]["Tables"]["inventory"]["Row"]
export type Customer = Database["public"]["Tables"]["customers"]["Row"]
export type Order = Database["public"]["Tables"]["orders"]["Row"]
export type OrderItem = Database["public"]["Tables"]["order_items"]["Row"]

// Expenses
export async function getExpenses() {
  // استخدام البيانات الوهمية دائمًا
  return getMockExpenses()
}

export async function addExpense(expense: Omit<Expense, "id" | "created_at">) {
  // محاكاة إضافة مصروف جديد
  await new Promise((resolve) => setTimeout(resolve, 500))

  const newExpense = {
    id: Math.floor(Math.random() * 1000) + 10,
    ...expense,
    created_at: new Date().toISOString(),
  }

  return newExpense
}

// Inventory
export async function getInventory() {
  // استخدام البيانات الوهمية دائمًا
  return getMockInventory()
}

export async function addInventoryItem(item: Omit<Inventory, "id" | "created_at">) {
  // محاكاة إضافة منتج جديد
  await new Promise((resolve) => setTimeout(resolve, 500))

  const newItem = {
    id: Math.floor(Math.random() * 1000) + 10,
    ...item,
    created_at: new Date().toISOString(),
  }

  return newItem
}

export async function updateInventoryItem(id: number, item: Partial<Omit<Inventory, "id" | "created_at">>) {
  // محاكاة تحديث منتج
  await new Promise((resolve) => setTimeout(resolve, 500))

  const inventory = getMockInventory()
  const itemIndex = inventory.findIndex((i) => i.id === id)

  if (itemIndex === -1) {
    return null
  }

  const updatedItem = {
    ...inventory[itemIndex],
    ...item,
  }

  return updatedItem
}

// Customers
export async function getCustomers() {
  // استخدام البيانات الوهمية دائمًا
  return getMockCustomers()
}

export async function addCustomer(customer: Omit<Customer, "id" | "created_at" | "orders" | "total">) {
  // محاكاة إضافة عميل جديد
  await new Promise((resolve) => setTimeout(resolve, 500))

  const newCustomer = {
    id: Math.floor(Math.random() * 1000) + 10,
    ...customer,
    orders: 0,
    total: 0,
    created_at: new Date().toISOString(),
  }

  return newCustomer
}

// Orders
// تعديل وظيفة getOrders لتجنب استخدام العلاقات المتداخلة

// استبدل وظيفة getOrders الحالية بهذه:
export async function getOrders() {
  // أولاً، نحصل على الطلبات
  const { data: orders, error: ordersError } = await supabase
    .from("orders")
    .select("*")
    .order("order_date", { ascending: false })

  if (ordersError) {
    console.error("Error fetching orders:", ordersError)
    return []
  }

  // إذا لم تكن هناك طلبات، نعيد مصفوفة فارغة
  if (!orders || orders.length === 0) {
    return []
  }

  // نحصل على معرفات العملاء من الطلبات
  const customerIds = orders.map((order) => order.customer_id)

  // نحصل على بيانات العملاء
  const { data: customers, error: customersError } = await supabase
    .from("customers")
    .select("id, name, email, phone")
    .in("id", customerIds)

  if (customersError) {
    console.error("Error fetching customers:", customersError)
    return orders // نعيد الطلبات بدون بيانات العملاء
  }

  // ندمج بيانات العملاء مع الطلبات
  const ordersWithCustomers = orders.map((order) => {
    const customer = customers?.find((c) => c.id === order.customer_id)
    return {
      ...order,
      customers: customer || { name: "عميل غير معروف", email: "", phone: "" },
    }
  })

  return ordersWithCustomers
}

// تعديل وظيفة getOrderItems لتجنب استخدام العلاقات المتداخلة

// استبدل وظيفة getOrderItems الحالية بهذه:
export async function getOrderItems(orderId: number) {
  // أولاً، نحصل على عناصر الطلب
  const { data: orderItems, error: orderItemsError } = await supabase
    .from("order_items")
    .select("*")
    .eq("order_id", orderId)

  if (orderItemsError) {
    console.error("Error fetching order items:", orderItemsError)
    return []
  }

  // إذا لم تكن هناك عناصر، نعيد مصفوفة فارغة
  if (!orderItems || orderItems.length === 0) {
    return []
  }

  // نحصل على معرفات المنتجات من عناصر الطلب
  const productIds = orderItems.map((item) => item.product_id)

  // نحصل على بيانات المنتجات
  const { data: products, error: productsError } = await supabase
    .from("inventory")
    .select("id, name, code")
    .in("id", productIds)

  if (productsError) {
    console.error("Error fetching products:", productsError)
    return orderItems // نعيد عناصر الطلب بدون بيانات المنتجات
  }

  // ندمج بيانات المنتجات مع عناصر الطلب
  const orderItemsWithProducts = orderItems.map((item) => {
    const product = products?.find((p) => p.id === item.product_id)
    return {
      ...item,
      inventory: product || { name: "منتج غير معروف", code: "" },
    }
  })

  return orderItemsWithProducts
}

// Dashboard
export async function getDashboardStats() {
  // استخدام البيانات الوهمية دائمًا
  return getMockDashboardStats()
}

// Recent orders
export async function getRecentOrders(limit = 5) {
  // استخدام البيانات الوهمية دائمًا
  return getMockRecentOrders(limit)
}

// Low stock items
export async function getLowStockItems() {
  // استخدام البيانات الوهمية دائمًا
  return getMockLowStockItems()
}

// Employees
export async function getEmployees() {
  return getMockEmployees()
}

export async function addEmployee(employee: Omit<any, "id" | "created_at">) {
  // محاكاة إضافة موظف جديد
  await new Promise((resolve) => setTimeout(resolve, 500))

  const newEmployee = {
    id: Math.floor(Math.random() * 1000) + 10,
    ...employee,
    created_at: new Date().toISOString(),
  }

  return newEmployee
}

export async function updateEmployee(id: number, employee: Partial<Omit<any, "id" | "created_at">>) {
  // محاكاة تحديث بيانات موظف
  await new Promise((resolve) => setTimeout(resolve, 500))

  const employees = getMockEmployees()
  const employeeIndex = employees.findIndex((e) => e.id === id)

  if (employeeIndex === -1) {
    return null
  }

  const updatedEmployee = {
    ...employees[employeeIndex],
    ...employee,
  }

  return updatedEmployee
}

// Attendance
export async function getAttendance(employeeId?: number, month?: string) {
  return getMockAttendance(employeeId, month)
}

export async function addAttendanceRecord(record: Omit<any, "id" | "created_at">) {
  // محاكاة إضافة سجل حضور جديد
  await new Promise((resolve) => setTimeout(resolve, 500))

  const newRecord = {
    id: Math.floor(Math.random() * 1000) + 10,
    ...record,
    created_at: new Date().toISOString(),
  }

  return newRecord
}

// Salaries
export async function getSalaries(month?: string) {
  return getMockSalaries(month)
}

export async function processSalary(employeeId: number) {
  // محاكاة معالجة راتب موظف
  await new Promise((resolve) => setTimeout(resolve, 500))

  const salaries = getMockSalaries()
  return salaries.find((s) => s.employee_id === employeeId) || null
}

