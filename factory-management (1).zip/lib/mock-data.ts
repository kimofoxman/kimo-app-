// وظائف إنشاء البيانات الوهمية

// المصروفات
export function getMockExpenses() {
  return [
    {
      id: 1,
      description: "فواتير الكهرباء",
      category: "مرافق",
      date: "2023-05-12",
      amount: 2500,
      created_at: new Date().toISOString(),
    },
    {
      id: 2,
      description: "رواتب الموظفين",
      category: "رواتب",
      date: "2023-05-10",
      amount: 15000,
      created_at: new Date().toISOString(),
    },
    {
      id: 3,
      description: "شراء مواد خام",
      category: "مواد خام",
      date: "2023-05-08",
      amount: 7800,
      created_at: new Date().toISOString(),
    },
    {
      id: 4,
      description: "صيانة المعدات",
      category: "صيانة",
      date: "2023-05-05",
      amount: 1200,
      created_at: new Date().toISOString(),
    },
    {
      id: 5,
      description: "فواتير المياه",
      category: "مرافق",
      date: "2023-05-03",
      amount: 800,
      created_at: new Date().toISOString(),
    },
  ]
}

// المخزون
export function getMockInventory() {
  return [
    {
      id: 1,
      code: "P001",
      name: "منتج أ",
      category: "فئة 1",
      quantity: 150,
      price: 250,
      status: "متوفر",
      created_at: new Date().toISOString(),
    },
    {
      id: 2,
      code: "P002",
      name: "منتج ب",
      category: "فئة 2",
      quantity: 75,
      price: 320,
      status: "متوفر",
      created_at: new Date().toISOString(),
    },
    {
      id: 3,
      code: "P003",
      name: "منتج ج",
      category: "فئة 1",
      quantity: 5,
      price: 180,
      status: "منخفض",
      created_at: new Date().toISOString(),
    },
    {
      id: 4,
      code: "P004",
      name: "منتج د",
      category: "فئة 3",
      quantity: 0,
      price: 420,
      status: "غير متوفر",
      created_at: new Date().toISOString(),
    },
    {
      id: 5,
      code: "P005",
      name: "منتج هـ",
      category: "فئة 2",
      quantity: 200,
      price: 150,
      status: "متوفر",
      created_at: new Date().toISOString(),
    },
  ]
}

// العملاء
export function getMockCustomers() {
  return [
    {
      id: 1,
      name: "أحمد محمد",
      email: "ahmed@example.com",
      phone: "01012345678",
      orders: 12,
      total: 15600,
      created_at: new Date().toISOString(),
    },
    {
      id: 2,
      name: "سارة أحمد",
      email: "sara@example.com",
      phone: "01123456789",
      orders: 8,
      total: 9200,
      created_at: new Date().toISOString(),
    },
    {
      id: 3,
      name: "محمد علي",
      email: "mohamed@example.com",
      phone: "01234567890",
      orders: 15,
      total: 18500,
      created_at: new Date().toISOString(),
    },
    {
      id: 4,
      name: "فاطمة حسن",
      email: "fatma@example.com",
      phone: "01198765432",
      orders: 5,
      total: 4800,
      created_at: new Date().toISOString(),
    },
    {
      id: 5,
      name: "خالد عبدالله",
      email: "khaled@example.com",
      phone: "01087654321",
      orders: 20,
      total: 25000,
      created_at: new Date().toISOString(),
    },
  ]
}

// إحصائيات لوحة التحكم
export function getMockDashboardStats() {
  return {
    totalSales: 45231,
    productsCount: 573,
    customersCount: 249,
    totalExpenses: 12234,
  }
}

// الطلبات الحديثة
export function getMockRecentOrders(limit = 5) {
  return Array.from({ length: limit }, (_, i) => ({
    id: 1000 + i,
    customer_id: (i % 5) + 1,
    order_date: new Date(Date.now() - i * 86400000).toISOString(),
    status: i % 3 === 0 ? "مكتمل" : i % 3 === 1 ? "قيد التنفيذ" : "ملغي",
    total: 1000 + i * 500,
    created_at: new Date().toISOString(),
    customers: {
      name: getMockCustomers()[i % 5].name,
    },
  }))
}

// المنتجات منخفضة المخزون
export function getMockLowStockItems() {
  return getMockInventory().filter((item) => item.status === "منخفض")
}

// الموظفين
export function getMockEmployees() {
  return [
    {
      id: 1,
      name: "محمد أحمد",
      position: "مدير إنتاج",
      department: "الإنتاج",
      phone: "01012345678",
      email: "mohamed@example.com",
      salary: 8000,
      join_date: "2020-01-15",
      status: "نشط",
      created_at: new Date().toISOString(),
    },
    {
      id: 2,
      name: "أحمد علي",
      position: "مهندس جودة",
      department: "الجودة",
      phone: "01123456789",
      email: "ahmed@example.com",
      salary: 6500,
      join_date: "2020-03-10",
      status: "نشط",
      created_at: new Date().toISOString(),
    },
    {
      id: 3,
      name: "سارة محمود",
      position: "محاسب",
      department: "المالية",
      phone: "01234567890",
      email: "sara@example.com",
      salary: 5500,
      join_date: "2021-02-01",
      status: "نشط",
      created_at: new Date().toISOString(),
    },
    {
      id: 4,
      name: "خالد عمر",
      position: "فني صيانة",
      department: "الصيانة",
      phone: "01198765432",
      email: "khaled@example.com",
      salary: 4500,
      join_date: "2021-05-20",
      status: "نشط",
      created_at: new Date().toISOString(),
    },
    {
      id: 5,
      name: "فاطمة سعيد",
      position: "مسؤول مخزن",
      department: "المخازن",
      phone: "01087654321",
      email: "fatma@example.com",
      salary: 4800,
      join_date: "2022-01-10",
      status: "نشط",
      created_at: new Date().toISOString(),
    },
  ]
}

// سجل الحضور والانصراف
export function getMockAttendance(employeeId?: number, month?: string) {
  const baseDate = new Date()
  const currentMonth = baseDate.getMonth()
  const currentYear = baseDate.getFullYear()

  // إنشاء سجلات الحضور لشهر كامل
  const records = []

  // عدد الأيام في الشهر الحالي
  const daysInMonth = new Date(currentYear, currentMonth + 1, 0).getDate()

  for (let day = 1; day <= daysInMonth; day++) {
    // تخطي أيام الجمعة (عطلة أسبوعية)
    const currentDate = new Date(currentYear, currentMonth, day)
    if (currentDate.getDay() === 5) continue // الجمعة

    // إنشاء سجلات لكل موظف
    const employees = getMockEmployees()
    for (const employee of employees) {
      // إذا تم تحديد موظف معين، نقوم بتصفية السجلات
      if (employeeId && employee.id !== employeeId) continue

      // إنشاء وقت حضور وانصراف عشوائي
      const checkInHour = 8 + Math.floor(Math.random() * 2) // بين 8 و 9 صباحًا
      const checkInMinute = Math.floor(Math.random() * 60)
      const checkOutHour = 16 + Math.floor(Math.random() * 2) // بين 4 و 5 مساءً
      const checkOutMinute = Math.floor(Math.random() * 60)

      // تنسيق التاريخ والوقت
      const dateStr = `${currentYear}-${String(currentMonth + 1).padStart(2, "0")}-${String(day).padStart(2, "0")}`
      const checkInTime = `${String(checkInHour).padStart(2, "0")}:${String(checkInMinute).padStart(2, "0")}`
      const checkOutTime = `${String(checkOutHour).padStart(2, "0")}:${String(checkOutMinute).padStart(2, "0")}`

      // حساب ساعات العمل
      const workHours = checkOutHour - checkInHour + (checkOutMinute - checkInMinute) / 60

      // إضافة السجل
      records.push({
        id: records.length + 1,
        employee_id: employee.id,
        employee_name: employee.name,
        date: dateStr,
        check_in: checkInTime,
        check_out: checkOutTime,
        work_hours: Number.parseFloat(workHours.toFixed(2)),
        status: checkInHour > 9 ? "متأخر" : "في الوقت",
        created_at: new Date().toISOString(),
      })
    }
  }

  return records
}

// حساب الرواتب
export function getMockSalaries(month?: string) {
  const employees = getMockEmployees()
  const attendance = getMockAttendance()

  // تجميع سجلات الحضور حسب الموظف
  const attendanceByEmployee = attendance.reduce(
    (acc, record) => {
      if (!acc[record.employee_id]) {
        acc[record.employee_id] = []
      }
      acc[record.employee_id].push(record)
      return acc
    },
    {} as Record<number, typeof attendance>,
  )

  // حساب الرواتب لكل موظف
  return employees.map((employee) => {
    const employeeAttendance = attendanceByEmployee[employee.id] || []

    // حساب إجمالي أيام العمل وساعات العمل
    const workDays = employeeAttendance.length
    const workHours = employeeAttendance.reduce((sum, record) => sum + record.work_hours, 0)
    const lateCount = employeeAttendance.filter((record) => record.status === "متأخر").length

    // حساب الخصومات (50 جنيه لكل يوم تأخير)
    const deductions = lateCount * 50

    // حساب المكافآت (10% من الراتب إذا كان عدد أيام التأخير أقل من 3)
    const bonus = lateCount < 3 ? employee.salary * 0.1 : 0

    // حساب صافي الراتب
    const netSalary = employee.salary + bonus - deductions

    return {
      id: employee.id,
      employee_id: employee.id,
      employee_name: employee.name,
      position: employee.position,
      department: employee.department,
      month: new Date().toLocaleDateString("ar-EG", { month: "long", year: "numeric" }),
      basic_salary: employee.salary,
      work_days: workDays,
      work_hours: Number.parseFloat(workHours.toFixed(2)),
      late_count: lateCount,
      deductions: deductions,
      bonus: bonus,
      net_salary: netSalary,
      status: "مدفوع",
      payment_date: new Date().toISOString().split("T")[0],
      created_at: new Date().toISOString(),
    }
  })
}

