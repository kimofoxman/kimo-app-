// إنشاء عميل وهمي لـ Supabase
// سنستخدم البيانات الوهمية بدلاً من الاتصال بقاعدة البيانات
export const supabase = null

