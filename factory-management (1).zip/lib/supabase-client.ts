"use client"

import { createClientComponentClient } from "@supabase/auth-helpers-nextjs"
import type { Database } from "@/types/supabase"

// إنشاء عميل Supabase للمكونات العميلة
// هذا سيعمل حتى إذا لم تكن متغيرات البيئة موجودة، لكن سيظهر خطأ في وحدة التحكم
export const supabaseClient = createClientComponentClient<Database>()

